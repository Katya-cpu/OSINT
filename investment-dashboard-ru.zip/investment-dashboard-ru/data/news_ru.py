"""
Модуль сбора новостей и аналитики из интернета.
RSS + Web-scraping инвестиционных источников.
"""
import feedparser
import requests
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
import re
from config import (
    RSS_FEEDS, TICKER_NEWS_KEYWORDS,
    SECTOR_GEO_KEYWORDS, MOEX_SECTORS
)
HTTP_TIMEOUT = 10
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/120.0.0.0 Safari/537.36",
    "Accept-Language": "ru-RU,ru;q=0.9",
}


# ============================================================
# RSS-ИСТОЧНИКИ
# ============================================================

def get_all_news(limit_per_source: int = 20) -> list:
    """Загрузка RSS из всех источников."""
    all_articles = []
    for source_name, url in RSS_FEEDS.items():
        try:
            feed = feedparser.parse(url)
            for entry in feed.entries[:limit_per_source]:
                published = ""
                if hasattr(entry, "published"):
                    published = entry.published
                elif hasattr(entry, "updated"):
                    published = entry.updated

                all_articles.append({
                    "title": entry.get("title", ""),
                    "description": entry.get("summary",
                                             entry.get("description", "")),
                    "link": entry.get("link", ""),
                    "source": source_name,
                    "published": published,
                })
        except Exception:
            continue
    return all_articles


def get_market_news(limit: int = 30) -> list:
    """
    Получает общие рыночные новости для вкладки News.
    Фильтрует по финансовой тематике.
    """
    all_news = get_all_news(limit_per_source=30)
    finance_kw = [
        "акци", "облигаци", "биржа", "индекс", "рынок",
        "инвест", "дивиденд", "ставк", "рубл", "доллар",
        "нефть", "газпром", "сбербанк", "лукойл", "moex",
        "мосбирж", "котировк", "портфель", "фонд",
        "цб рф", "центробанк", "минфин", "торг",
    ]
    relevant = []
    for article in all_news:
        text = (article.get("title", "") + " " +
                article.get("description", "")).lower()
        if any(kw in text for kw in finance_kw):
            relevant.append(article)
            if len(relevant) >= limit:
                break
    # Если мало финансовых — вернуть все
    return relevant if relevant else all_news[:limit]


def search_news(query: str, limit: int = 20) -> list:
    """
    Поиск новостей по ключевому запросу.
    Ищет во всех RSS + по запросу в заголовках и описаниях.
    """
    all_news = get_all_news(limit_per_source=30)
    query_lower = query.lower().strip()
    keywords = [kw.strip() for kw in query_lower.split() if len(kw.strip()) > 2]

    if not keywords:
        return all_news[:limit]

    results = []
    for article in all_news:
        text = (article.get("title", "") + " " +
                article.get("description", "")).lower()
        # Если хотя бы одно слово из запроса найдено
        if any(kw in text for kw in keywords):
            results.append(article)
            if len(results) >= limit:
                break
    return results


def get_sector_news(sector: str, ticker: str = None,
                    limit: int = 15) -> dict:
    """
    Глубокий 4-категорийный поиск новостей.
    Загружает БОЛЬШЕ записей из RSS для полноты картины.
    """
    # Берём до 50 записей с каждого источника — захватываем неделю
    all_news = get_all_news(limit_per_source=50)
    result = {"company": [], "sector": [], "geopolitics": [], "macro": []}

    if not all_news:
        return result

    # Ключевые слова компании
    company_kw = []
    if ticker and ticker in TICKER_NEWS_KEYWORDS:
        company_kw = [kw.lower() for kw in TICKER_NEWS_KEYWORDS[ticker]]
    if ticker:
        company_kw.append(ticker.lower())

    # Секторные ключевые слова (3 уровня)
    sector_kw = []
    geo_kw = []
    macro_kw = []
    if sector in SECTOR_GEO_KEYWORDS:
        sk = SECTOR_GEO_KEYWORDS[sector]
        sector_kw = [w.lower() for w in sk.get("sector",
                                                sk.get("direct", []))]
        geo_kw = [w.lower() for w in sk.get("geopolitics",
                                             sk.get("geo", []))]
        macro_kw = [w.lower() for w in sk.get("macro", [])]

    # Общие макро-слова (всегда актуальны)
    general_macro = [
        "ключевая ставка", "цб рф", "центробанк", "инфляция",
        "ввп россии", "минфин", "бюджет", "рецессия",
        "девальвация", "ослабление рубля", "укрепление рубля",
        "набиуллина", "силуанов", "минэкономразвития",
    ]
    macro_kw.extend(general_macro)

    # Универсальные геополитические слова (ловят крупные события)
    universal_geo = [
        "санкци", "война", "конфликт", "перемири",
        "ближний восток", "иран", "сирия", "украин",
        "нато", "опек", "эмбарго", "блокад",
        "ормуз", "красное море", "хуситы",
        "торговая война", "пошлин", "тариф",
        "ядерн", "дипломат", "переговор",
    ]
    geo_kw.extend(universal_geo)

    for article in all_news:
        text = (
            article.get("title", "") + " " +
            article.get("description", "")
        ).lower()

        # Категория: компания
        if company_kw and any(kw in text for kw in company_kw):
            if len(result["company"]) < limit:
                result["company"].append(article)
            continue

        # Категория: сектор (прямые отраслевые)
        if sector_kw and any(kw in text for kw in sector_kw):
            if len(result["sector"]) < limit:
                result["sector"].append(article)
            continue

        # Категория: геополитика (1+ совпадение из расширенного списка)
        if geo_kw:
            geo_matches = sum(1 for kw in geo_kw if kw in text)
            if geo_matches >= 1:
                if len(result["geopolitics"]) < limit:
                    result["geopolitics"].append(article)
                continue

        # Категория: макро
        if macro_kw:
            macro_matches = sum(1 for kw in macro_kw if kw in text)
            finance_context = any(w in text for w in [
                "рынок", "акци", "облигаци", "биржа", "инвест",
                "доход", "портфель", "котировк", "индекс",
            ])
            if macro_matches >= 1 and finance_context:
                if len(result["macro"]) < limit:
                    result["macro"].append(article)

    return result


# ============================================================
# ГЕОПОЛИТИЧЕСКИЙ КОНТЕКСТ (для LLM)
# ============================================================

def build_geopolitical_context(sector: str) -> str:
    """
    Строит блок текущего геополитического контекста для LLM.
    Парсит свежие заголовки из нескольких источников,
    фильтрует по релевантности сектору.
    Это даёт AI более полную картину чем только RSS.
    """
    sections = []

    # 1. ТАСС — международные новости (много геополитики)
    geo_urls = [
        ("ТАСС Международное",
         "https://tass.ru/rss/v2.xml"),
        ("РИА Новости",
         "https://ria.ru/export/rss2/archive/index.xml"),
    ]
    geo_articles = []
    for name, url in geo_urls:
        try:
            feed = feedparser.parse(url)
            for entry in feed.entries[:40]:
                title = entry.get("title", "")
                desc = entry.get("summary", entry.get("description", ""))
                geo_articles.append({
                    "title": title,
                    "description": desc,
                    "source": name,
                })
        except Exception:
            continue

    # Фильтруем по геополитическим/экономическим ключевым словам
    geo_filter = [
        "нефть", "газ", "опек", "санкци", "война", "конфликт",
        "ближний восток", "иран", "хуситы", "красное море",
        "сирия", "украин", "нато", "китай", "сша",
        "торговая война", "пошлин", "эмбарго", "танкер",
        "перемири", "переговор", "дипломат",
        "ставка", "центробанк", "инфляция", "рецессия",
        "рубль", "доллар", "юань", "евро",
        "ввп", "экономик", "кризис", "дефолт",
        "металл", "золото", "алюминий", "никель",
        "зерно", "удобрени", "экспорт", "импорт",
    ]

    # Добавляем секторные ключевые слова
    if sector in SECTOR_GEO_KEYWORDS:
        sk = SECTOR_GEO_KEYWORDS[sector]
        for key in ["sector", "direct", "geopolitics", "geo", "macro"]:
            if key in sk:
                geo_filter.extend([w.lower() for w in sk[key]])

    relevant_geo = []
    seen_titles = set()
    for article in geo_articles:
        text = (article["title"] + " " +
                article.get("description", "")).lower()
        if any(kw in text for kw in geo_filter):
            title_short = article["title"][:60]
            if title_short not in seen_titles:
                seen_titles.add(title_short)
                relevant_geo.append(article)
                if len(relevant_geo) >= 20:
                    break

    if relevant_geo:
        lines = []
        for a in relevant_geo:
            lines.append(f"  - [{a['source']}] {a['title']}")
        sections.append(
            "=== ГЕОПОЛИТИЧЕСКИЙ КОНТЕКСТ (свежие события) ===\n" +
            "\n".join(lines)
        )

    # 2. Нефть и сырьё — актуальный контекст
    commodity_articles = []
    for article in geo_articles:
        text = (article["title"] + " " +
                article.get("description", "")).lower()
        if any(kw in text for kw in [
            "нефть", "brent", "wti", "опек", "газ",
            "спг", "трубопровод", "танкер",
        ]):
            commodity_articles.append(article)

    if commodity_articles:
        lines = [f"  - [{a['source']}] {a['title']}"
                 for a in commodity_articles[:8]]
        sections.append(
            "=== НЕФТЬ И СЫРЬЁ ===\n" + "\n".join(lines)
        )

    return "\n\n".join(sections) if sections else ""


# ============================================================
# WEB-SCRAPING: ИНВЕСТИЦИОННАЯ АНАЛИТИКА
# ============================================================

def _safe_get(url: str, timeout: int = HTTP_TIMEOUT) -> str:
    """Безопасный HTTP GET с возвратом текста страницы."""
    try:
        resp = requests.get(url, headers=HEADERS, timeout=timeout)
        resp.raise_for_status()
        resp.encoding = resp.apparent_encoding or "utf-8"
        return resp.text
    except Exception:
        return ""


def _extract_text_from_html(html: str, max_chars: int = 3000) -> str:
    """Извлечение чистого текста из HTML."""
    if not html:
        return ""
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "nav", "header", "footer",
                     "aside", "form", "iframe", "noscript"]):
        tag.decompose()
    text = soup.get_text(separator=" ", strip=True)
    text = re.sub(r'\s+', ' ', text)
    return text[:max_chars]


def scrape_smart_lab_ticker(ticker: str) -> dict:
    """Парсит smart-lab.ru — фундаментал + обсуждения."""
    result = {"consensus": "", "discussions": [], "fundamentals": ""}

    url = f"https://smart-lab.ru/q/{ticker}/"
    html = _safe_get(url)
    if html:
        soup = BeautifulSoup(html, "html.parser")
        tables = soup.find_all("table")
        fund_data = []
        for table in tables[:3]:
            rows = table.find_all("tr")
            for row in rows:
                cells = row.find_all(["td", "th"])
                if len(cells) >= 2:
                    label = cells[0].get_text(strip=True)
                    value = cells[1].get_text(strip=True)
                    if label and value and len(label) < 50:
                        fund_data.append(f"{label}: {value}")
        if fund_data:
            result["fundamentals"] = "\n".join(fund_data[:20])

    blog_url = f"https://smart-lab.ru/q/{ticker}/blog/"
    html = _safe_get(blog_url)
    if html:
        soup = BeautifulSoup(html, "html.parser")
        posts = soup.find_all("div", class_="topic")
        if not posts:
            posts = soup.find_all("article")
        if not posts:
            links = soup.find_all("a", href=True)
            for link in links:
                title = link.get_text(strip=True)
                if len(title) > 20:
                    result["discussions"].append(title)
                    if len(result["discussions"]) >= 7:
                        break
        else:
            for post in posts[:7]:
                title_el = post.find(["h2", "h3", "a"])
                if title_el:
                    result["discussions"].append(
                        title_el.get_text(strip=True))

    return result


def scrape_investing_com_ru(ticker: str) -> str:
    """Парсит ru.investing.com — техническая сводка."""
    ticker_map = {
        "SBER": "sberbank", "GAZP": "gazprom", "LKOH": "lukoil",
        "GMKN": "gmk-noril-nickel", "ROSN": "rosneft",
        "NVTK": "novatek", "YNDX": "yandex-n.v.", "MTSS": "mts",
        "MGNT": "magnit", "POLY": "polymetal-international",
        "PLZL": "polyus-gold", "ALRS": "alrosa",
        "CHMF": "severstal", "NLMK": "nlmk",
        "TATN": "tatneft", "SNGS": "surgutneftegaz",
        "VTBR": "vtb-bank", "MOEX": "moex",
        "PHOR": "phosagro", "RUAL": "rusal",
        "IRAO": "inter-rao-ees", "FEES": "rosseti",
        "AFKS": "afk-sistema", "PIKK": "pik-group",
        "TRNFP": "transneft-pref", "MAGN": "mmk",
    }
    slug = ticker_map.get(ticker)
    if not slug:
        return ""

    url = f"https://ru.investing.com/equities/{slug}-technical"
    html = _safe_get(url)
    if not html:
        return ""

    text = _extract_text_from_html(html, max_chars=2000)
    keywords = ["покуп", "продаж", "нейтрально", "сводка",
                "скользящ", "осциллятор", "сильн"]
    relevant = []
    for s in text.split("."):
        if any(kw in s.lower() for kw in keywords):
            relevant.append(s.strip())
    return ". ".join(relevant[:10]) if relevant else text[:500]


def scrape_bcs_analytics(ticker: str) -> str:
    """Парсит аналитику БКС."""
    url = f"https://bcs-express.ru/kotirovki-i-grafiki/{ticker.lower()}"
    html = _safe_get(url)
    if not html:
        return ""
    text = _extract_text_from_html(html, max_chars=2000)
    keywords = ["прогноз", "целев", "рекоменд", "консенсус",
                "потенциал", "дивиденд", "отчёт", "аналитик"]
    relevant = []
    for s in text.split("."):
        if any(kw in s.lower() for kw in keywords):
            relevant.append(s.strip())
    return ". ".join(relevant[:8]) if relevant else ""


def scrape_tinkoff_analytics(ticker: str) -> str:
    """Парсит консенсус Тинькофф."""
    url = f"https://www.tinkoff.ru/invest/stocks/{ticker}/"
    html = _safe_get(url)
    if not html:
        return ""
    text = _extract_text_from_html(html, max_chars=2000)
    keywords = ["прогноз", "консенсус", "аналитик", "целев",
                "рекоменд", "дивиденд", "мультиплик"]
    relevant = []
    for s in text.split("."):
        if any(kw in s.lower() for kw in keywords):
            relevant.append(s.strip())
    return ". ".join(relevant[:8]) if relevant else ""


def scrape_dohod_ru_dividends(ticker: str) -> str:
    """Парсит dohod.ru — дивиденды."""
    url = f"https://www.dohod.ru/ik/analytics/dividend/{ticker.lower()}"
    html = _safe_get(url)
    if not html:
        return ""
    text = _extract_text_from_html(html, max_chars=1500)
    keywords = ["дивиденд", "доходност", "выплат", "дата", "размер",
                "прогноз", "история", "закрытие реестра"]
    relevant = []
    for s in text.split("."):
        if any(kw in s.lower() for kw in keywords):
            relevant.append(s.strip())
    return ". ".join(relevant[:8]) if relevant else ""


def scrape_moex_description(ticker: str) -> str:
    """Описание компании с MOEX API."""
    url = (f"https://iss.moex.com/iss/securities/{ticker}.json"
           f"?iss.meta=off&iss.only=description")
    try:
        resp = requests.get(url, timeout=HTTP_TIMEOUT)
        data = resp.json()
        desc_data = data.get("description", {}).get("data", [])
        info = {}
        for row in desc_data:
            if len(row) >= 3:
                info[row[0]] = row[2]
        parts = []
        for key in ["SHORTNAME", "TYPENAME", "LISTLEVEL",
                     "ISSUESIZE", "FACEVALUE", "LOTSIZE"]:
            if key in info:
                parts.append(f"{key}: {info[key]}")
        return "; ".join(parts)
    except Exception:
        return ""


def get_deep_web_analysis(ticker: str, sector: str) -> dict:
    """Глубокий сбор данных из интернета."""
    result = {
        "smart_lab": {"fundamentals": "", "discussions": [],
                      "consensus": ""},
        "investing_com": "",
        "bcs": "",
        "tinkoff": "",
        "dohod_dividends": "",
        "moex_info": "",
        "geo_context": "",
    }

    result["smart_lab"] = scrape_smart_lab_ticker(ticker)
    result["investing_com"] = scrape_investing_com_ru(ticker)
    result["bcs"] = scrape_bcs_analytics(ticker)
    result["tinkoff"] = scrape_tinkoff_analytics(ticker)
    result["dohod_dividends"] = scrape_dohod_ru_dividends(ticker)
    result["moex_info"] = scrape_moex_description(ticker)
    result["geo_context"] = build_geopolitical_context(sector)

    return result


def format_web_data_for_ai(web_data: dict) -> str:
    """Форматирует web-данные для LLM."""
    sections = []

    sl = web_data.get("smart_lab", {})
    if sl.get("fundamentals"):
        sections.append(
            f"=== SMART-LAB: ФУНДАМЕНТАЛ ===\n{sl['fundamentals']}")
    if sl.get("discussions"):
        disc = "\n".join(f"  - {d}" for d in sl["discussions"])
        sections.append(f"=== SMART-LAB: ОБСУЖДЕНИЯ ===\n{disc}")

    if web_data.get("investing_com"):
        sections.append(
            f"=== INVESTING.COM: ТЕХ.СВОДКА ===\n"
            f"{web_data['investing_com']}")

    if web_data.get("bcs"):
        sections.append(f"=== БКС: АНАЛИТИКА ===\n{web_data['bcs']}")

    if web_data.get("tinkoff"):
        sections.append(
            f"=== ТИНЬКОФФ: КОНСЕНСУС ===\n{web_data['tinkoff']}")

    if web_data.get("dohod_dividends"):
        sections.append(
            f"=== DOHOD.RU: ДИВИДЕНДЫ ===\n"
            f"{web_data['dohod_dividends']}")

    if web_data.get("moex_info"):
        sections.append(
            f"=== MOEX: ОПИСАНИЕ ===\n{web_data['moex_info']}")

    if web_data.get("geo_context"):
        sections.append(web_data["geo_context"])

    return "\n\n".join(sections) if sections else "Web-данные не найдены."


def scrape_market_overview() -> str:
    """Общий обзор рынка для Market/Advisor."""
    sections = []

    html = _safe_get("https://smart-lab.ru/")
    if html:
        text = _extract_text_from_html(html, max_chars=2000)
        keywords = ["индекс", "рынок", "нефть", "рубл", "газ",
                     "санкци", "ставк", "рост", "падени"]
        relevant = []
        for s in text.split("."):
            if any(kw in s.lower() for kw in keywords):
                relevant.append(s.strip())
        if relevant:
            sections.append(
                "=== SMART-LAB: ОБЗОР ===\n" +
                ". ".join(relevant[:10]))

    html = _safe_get("https://bcs-express.ru/category/rynok")
    if html:
        soup = BeautifulSoup(html, "html.parser")
        headlines = []
        for a in soup.find_all("a", href=True):
            title = a.get_text(strip=True)
            if 20 < len(title) < 150:
                headlines.append(title)
                if len(headlines) >= 10:
                    break
        if headlines:
            sections.append(
                "=== БКС: ЗАГОЛОВКИ ===\n" +
                "\n".join(f"  - {h}" for h in headlines))

    return "\n\n".join(sections) if sections else ""


def scrape_bond_analytics() -> str:
    """Аналитика облигаций."""
    sections = []
    html = _safe_get("https://smart-lab.ru/bonds/")
    if html:
        text = _extract_text_from_html(html, max_chars=1500)
        keywords = ["офз", "доходност", "купон", "погашени",
                     "дюрац", "ставк"]
        relevant = []
        for s in text.split("."):
            if any(kw in s.lower() for kw in keywords):
                relevant.append(s.strip())
        if relevant:
            sections.append(
                "=== SMART-LAB: ОБЛИГАЦИИ ===\n" +
                ". ".join(relevant[:8]))
    return "\n\n".join(sections) if sections else ""