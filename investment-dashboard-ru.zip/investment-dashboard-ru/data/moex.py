import requests
import pandas as pd
from datetime import datetime, timedelta

MOEX_BASE = "https://iss.moex.com/iss"


def _moex_get(path: str, params: dict = None) -> dict:
    """Базовый запрос к MOEX ISS API."""
    url = f"{MOEX_BASE}/{path}.json"
    default_params = {"iss.meta": "off", "iss.json": "extended"}
    if params:
        default_params.update(params)
    try:
        r = requests.get(url, params=default_params, timeout=15)
        return r.json()
    except Exception:
        return {}


def get_shares_realtime() -> pd.DataFrame:
    """Текущие котировки акций TQBR."""
    url = f"{MOEX_BASE}/engines/stock/markets/shares/boards/TQBR/securities.json"
    params = {"iss.meta": "off"}
    try:
        r = requests.get(url, params=params, timeout=15)
        data = r.json()
        # Securities block
        sec_block = data.get("securities", {})
        sec_cols = sec_block.get("columns", [])
        sec_rows = sec_block.get("data", [])
        df_sec = pd.DataFrame(sec_rows, columns=sec_cols)

        # Marketdata block
        md_block = data.get("marketdata", {})
        md_cols = md_block.get("columns", [])
        md_rows = md_block.get("data", [])
        df_md = pd.DataFrame(md_rows, columns=md_cols)

        if df_sec.empty or df_md.empty:
            return pd.DataFrame()

        # Убираем дублирующиеся колонки перед merge
        common_cols = set(df_sec.columns) & set(df_md.columns) - {"SECID"}
        df_md_clean = df_md.drop(columns=list(common_cols), errors="ignore")

        df = df_sec.merge(df_md_clean, on="SECID", how="inner")

        # Фильтр — LAST может называться по-разному
        last_col = None
        for col_name in ["LAST", "MARKETPRICE", "CURRENTVALUE"]:
            if col_name in df.columns:
                last_col = col_name
                break

        if last_col is None:
            # Если LAST не нашли — вернуть всё, что есть
            return df

        df[last_col] = pd.to_numeric(df[last_col], errors="coerce")
        df = df[df[last_col].notna() & (df[last_col] > 0)]

        # Стандартизируем имя
        if last_col != "LAST":
            df = df.rename(columns={last_col: "LAST"})

        return df
    except Exception as e:
        print(f"MOEX API error: {e}")
        return pd.DataFrame()


def get_index_current() -> dict:
    """Текущие значения основных индексов."""
    url = f"{MOEX_BASE}/engines/stock/markets/index/securities.json"
    params = {"iss.meta": "off", "iss.only": "marketdata,securities"}
    try:
        r = requests.get(url, params=params, timeout=15)
        data = r.json()

        sec_cols = data["securities"]["columns"]
        sec_rows = data["securities"]["data"]
        df_sec = pd.DataFrame(sec_rows, columns=sec_cols)

        md_cols = data["marketdata"]["columns"]
        md_rows = data["marketdata"]["data"]
        df_md = pd.DataFrame(md_rows, columns=md_cols)

        df = df_sec.merge(df_md, on="SECID", suffixes=("", "_md"))

        result = {}
        for idx in ["IMOEX", "RTSI", "MOEXBC", "RGBITR"]:
            row = df[df["SECID"] == idx]
            if not row.empty:
                r = row.iloc[0]
                result[idx] = {
                    "name": r.get("SHORTNAME", idx),
                    "value": r.get("CURRENTVALUE") or r.get("LAST"),
                    "change_%": r.get("LASTCHANGEPRCNT") or r.get("LASTTOPREVPRICE"),
                }
        return result
    except Exception:
        return {}


def get_index_history(index: str = "IMOEX", days: int = 365) -> pd.DataFrame:
    """История индекса MOEX."""
    end = datetime.now()
    start = end - timedelta(days=days)
    path = f"history/engines/stock/markets/index/securities/{index}"
    all_rows = []
    start_row = 0
    try:
        while True:
            data = _moex_get(path, {
                "from": start.strftime("%Y-%m-%d"),
                "till": end.strftime("%Y-%m-%d"),
                "start": start_row,
            })
            if not data or len(data) < 2:
                break
            block = data[1].get("history", [])
            if not block:
                break
            all_rows.extend(block)
            if len(block) < 100:
                break
            start_row += 100

        df = pd.DataFrame(all_rows)
        if not df.empty and "TRADEDATE" in df.columns:
            df["TRADEDATE"] = pd.to_datetime(df["TRADEDATE"])
            df = df.sort_values("TRADEDATE")
        return df
    except Exception:
        return pd.DataFrame()


def get_candles(ticker: str, interval: int = 24, days: int = 365) -> pd.DataFrame:
    """
    Свечи по тикеру.
    interval: 1=1мин, 10=10мин, 60=1час, 24=1день, 7=1нед, 31=1мес, 4=1квартал
    """
    end = datetime.now()
    start = end - timedelta(days=days)
    path = f"engines/stock/markets/shares/boards/TQBR/securities/{ticker}/candles"
    all_rows = []
    cursor_start = 0
    try:
        while True:
            data = _moex_get(path, {
                "from": start.strftime("%Y-%m-%d"),
                "till": end.strftime("%Y-%m-%d"),
                "interval": interval,
                "start": cursor_start,
            })
            if not data or len(data) < 2:
                break
            block = data[1].get("candles", [])
            if not block:
                break
            all_rows.extend(block)
            if len(block) < 500:
                break
            cursor_start += 500

        df = pd.DataFrame(all_rows)
        if not df.empty and "begin" in df.columns:
            df["date"] = pd.to_datetime(df["begin"])
            df = df.sort_values("date")
        return df
    except Exception:
        return pd.DataFrame()


def get_dividends_info(ticker: str) -> dict:
    """Дивидендная информация (из описания бумаги)."""
    path = f"securities/{ticker}"
    data = _moex_get(path)
    if not data or len(data) < 2:
        return {}
    desc = data[1].get("description", [])
    result = {}
    for item in desc:
        name = item.get("name", "")
        if name in ["SECNAME", "LOTSIZE", "ISSUESIZE", "LISTLEVEL", "ISQUALIFIEDINVESTORS"]:
            result[name] = item.get("value", "")
    return result


def get_ofz_bonds() -> pd.DataFrame:
    """Список ОФЗ (гособлигации)."""
    url = f"{MOEX_BASE}/engines/stock/markets/bonds/boards/TQOB/securities.json"
    params = {"iss.meta": "off", "iss.only": "securities,marketdata"}
    try:
        r = requests.get(url, params=params, timeout=15)
        data = r.json()

        sec_cols = data["securities"]["columns"]
        sec_rows = data["securities"]["data"]
        df_sec = pd.DataFrame(sec_rows, columns=sec_cols)

        md_cols = data["marketdata"]["columns"]
        md_rows = data["marketdata"]["data"]
        df_md = pd.DataFrame(md_rows, columns=md_cols)

        df = df_sec.merge(df_md, on="SECID", suffixes=("", "_md"))
        df = df[df["LAST"].notna() & (df["LAST"] > 0)]

        cols = ["SECID", "SHORTNAME", "LAST", "COUPONVALUE", "COUPONPERIOD",
                "NEXTCOUPON", "MATDATE", "ACCRUEDINT", "YIELDATPREVWAPRICE",
                "EFFECTIVEYIELD", "DURATION"]
        available = [c for c in cols if c in df.columns]
        return df[available].copy()
    except Exception:
        return pd.DataFrame()


def get_etf_list() -> pd.DataFrame:
    """Список ETF на MOEX."""
    url = f"{MOEX_BASE}/engines/stock/markets/shares/boards/TQTF/securities.json"
    params = {"iss.meta": "off", "iss.only": "securities,marketdata"}
    try:
        r = requests.get(url, params=params, timeout=15)
        data = r.json()

        sec_cols = data["securities"]["columns"]
        sec_rows = data["securities"]["data"]
        df_sec = pd.DataFrame(sec_rows, columns=sec_cols)

        md_cols = data["marketdata"]["columns"]
        md_rows = data["marketdata"]["data"]
        df_md = pd.DataFrame(md_rows, columns=md_cols)

        df = df_sec.merge(df_md, on="SECID", suffixes=("", "_md"))
        df = df[df["LAST"].notna() & (df["LAST"] > 0)]

        return df[["SECID", "SHORTNAME", "LAST", "CHANGE",
                    "LASTTOPREVPRICE", "VALTODAY"]].copy()
    except Exception:
        return pd.DataFrame()


def search_security(query: str) -> pd.DataFrame:
    """Поиск бумаги по тикеру или названию."""
    url = f"{MOEX_BASE}/securities.json"
    params = {"q": query, "iss.meta": "off", "limit": 10}
    try:
        r = requests.get(url, params=params, timeout=10)
        data = r.json()
        cols = data["securities"]["columns"]
        rows = data["securities"]["data"]
        return pd.DataFrame(rows, columns=cols)
    except Exception:
        return pd.DataFrame()