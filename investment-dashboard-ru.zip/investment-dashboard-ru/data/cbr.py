import requests
import pandas as pd
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET

def get_daily_rates() -> dict:
    """Текущие курсы ЦБ РФ."""
    url = "https://www.cbr-xml-daily.ru/daily_json.js"
    try:
        r = requests.get(url, timeout=10)
        data = r.json()

        currencies = {}
        for code in ["USD", "EUR", "CNY", "GBP", "JPY", "TRY", "KZT"]:
            if code in data.get("Valute", {}):
                v = data["Valute"][code]
                nominal = v.get("Nominal", 1)
                currencies[code] = {
                    "name": v["Name"],
                    "value": round(v["Value"] / nominal, 4),
                    "previous": round(v["Previous"] / nominal, 4),
                    "change": round((v["Value"] - v["Previous"]) / nominal, 4),
                    "nominal": nominal,
                }
        return {
            "date": data.get("Date", ""),
            "currencies": currencies,
        }
    except Exception:
        return {}


def get_all_currencies() -> pd.DataFrame:
    """Все валюты ЦБ РФ."""
    url = "https://www.cbr-xml-daily.ru/daily_json.js"
    try:
        r = requests.get(url, timeout=10)
        data = r.json()
        rows = []
        for code, info in data.get("Valute", {}).items():
            nominal = info.get("Nominal", 1)
            rows.append({
                "Код": code,
                "Валюта": info["Name"],
                "Номинал": nominal,
                "Курс": round(info["Value"] / nominal, 4),
                "Пред.": round(info["Previous"] / nominal, 4),
                "Изм.": round((info["Value"] - info["Previous"]) / nominal, 4),
            })
        return pd.DataFrame(rows)
    except Exception:
        return pd.DataFrame()


def get_currency_history(currency: str = "USD", days: int = 365) -> pd.DataFrame:
    """История курса валюты через ЦБ РФ XML API."""
    end = datetime.now()
    start = end - timedelta(days=days)

    # Маппинг валют к кодам ЦБ
    currency_ids = {
        "USD": "R01235", "EUR": "R01239", "CNY": "R01375",
        "GBP": "R01035", "JPY": "R01820",
    }

    cid = currency_ids.get(currency)
    if not cid:
        return pd.DataFrame()

    url = "https://www.cbr.ru/scripts/XML_dynamic.asp"
    params = {
        "date_req1": start.strftime("%d/%m/%Y"),
        "date_req2": end.strftime("%d/%m/%Y"),
        "VAL_NM_RQ": cid,
    }
    try:
        r = requests.get(url, params=params, timeout=15)
        r.encoding = "windows-1251"
        root = ET.fromstring(r.text)

        rows = []
        for record in root.findall("Record"):
            date_str = record.get("Date")
            nominal = int(record.find("Nominal").text)
            value = float(record.find("Value").text.replace(",", "."))
            rows.append({
                "date": pd.to_datetime(date_str, format="%d.%m.%Y"),
                "value": round(value / nominal, 4),
            })
        return pd.DataFrame(rows).sort_values("date")
    except Exception:
        return pd.DataFrame()


def get_key_rate_history() -> pd.DataFrame:
    """История ключевой ставки ЦБ РФ."""
    url = "https://www.cbr.ru/scripts/XML_KeyRate.asp"
    params = {
        "date_req1": "01/01/2015",
        "date_req2": datetime.now().strftime("%d/%m/%Y"),
    }
    try:
        r = requests.get(url, params=params, timeout=15)
        r.encoding = "windows-1251"
        root = ET.fromstring(r.text)

        rows = []
        for record in root.findall("Record"):
            date_str = record.get("DT")
            rate = float(record.find("Rate").text.replace(",", "."))
            rows.append({
                "date": pd.to_datetime(date_str, format="%d.%m.%Y"),
                "rate": rate,
            })
        return pd.DataFrame(rows).sort_values("date")
    except Exception:
        return pd.DataFrame()


def get_inflation_data() -> pd.DataFrame:
    """Инфляция РФ (из открытых данных ЦБ)."""
    # Используем уровень инфляции через API Росстата / cbr-xml-daily
    url = "https://www.cbr-xml-daily.ru/key_indicators.json"
    try:
        r = requests.get(url, timeout=10)
        data = r.json()
        # Ключевая ставка и инфляция из key_indicators
        result = {}
        if "key_rate" in data:
            result["key_rate"] = data["key_rate"]
        if "inflation" in data:
            result["inflation"] = data["inflation"]
        return result
    except Exception:
        return {}