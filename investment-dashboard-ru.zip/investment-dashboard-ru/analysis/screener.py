import pandas as pd
import numpy as np
from data.moex import get_shares_realtime, get_candles
from analysis.indicators import full_analysis
from config import MOEX_TICKERS, MOEX_SECTORS

def build_screener(tickers: list[str] = None) -> pd.DataFrame:
    """Быстрый скринер — котировки без свечей."""
    if tickers is None:
        tickers = MOEX_TICKERS

    shares = get_shares_realtime()
    if shares.empty:
        return pd.DataFrame()

    df = shares[shares["SECID"].isin(tickers)].copy()
    if df.empty:
        return pd.DataFrame()

    rows = []
    for _, row in df.iterrows():
        ticker = row["SECID"]
        last = row.get("LAST")
        if last is None or pd.isna(last):
            continue

        rows.append({
            "Тикер": ticker,
            "Название": row.get("SHORTNAME", ""),
            "Сектор": MOEX_SECTORS.get(ticker, "Другое"),
            "Цена": float(last),
            "Изм. %": float(row.get("LASTTOPREVPRICE") or 0),
            "Объём (руб)": row.get("VALTODAY") or 0,
        })

    return pd.DataFrame(rows)


def build_full_screener(tickers: list[str] = None) -> pd.DataFrame:
    """Полный скринер с техническими индикаторами."""
    if tickers is None:
        tickers = MOEX_TICKERS

    shares = get_shares_realtime()
    if shares.empty:
        return pd.DataFrame()

    df = shares[shares["SECID"].isin(tickers)].copy()
    if df.empty:
        return pd.DataFrame()

    rows = []
    for _, row in df.iterrows():
        ticker = row["SECID"]
        last = row.get("LAST")
        if last is None or pd.isna(last):
            continue

        # Загрузка свечей
        candles = get_candles(ticker, interval=24, days=180)
        if candles.empty or "close" not in candles.columns or len(candles) < 50:
            rows.append({
                "Тикер": ticker,
                "Название": row.get("SHORTNAME", ""),
                "Сектор": MOEX_SECTORS.get(ticker, "Другое"),
                "Цена": float(last),
                "Изм. %": float(row.get("LASTTOPREVPRICE") or 0),
                "RSI": None,
                "Сигнал": "Нет данных",
                "Сила": 0,
                "Тренд": "?",
                "1Д %": None, "1Н %": None, "1М %": None, "3М %": None,
                "Волат. %": None,
                "Поддержка": None, "Сопротивление": None,
                "MACD гист.": None, "BB ширина %": None,
                "Stoch K": None,
            })
            continue

        analysis = full_analysis(candles)
        if "error" in analysis:
            continue

        sig = analysis["signal"]

        rows.append({
            "Тикер": ticker,
            "Название": row.get("SHORTNAME", ""),
            "Сектор": MOEX_SECTORS.get(ticker, "Другое"),
            "Цена": analysis["price"],
            "Изм. %": analysis["return_1d"],
            "RSI": round(analysis["rsi"], 1),
            "Сигнал": sig["signal"],
            "Сила": sig["strength"],
            "Тренд": analysis["trend"],
            "1Д %": round(analysis["return_1d"], 2),
            "1Н %": round(analysis["return_1w"], 2),
            "1М %": round(analysis["return_1m"], 2),
            "3М %": round(analysis["return_3m"], 2),
            "Волат. %": round(analysis["volatility"], 1),
            "Поддержка": round(analysis["support"], 2),
            "Сопротивление": round(analysis["resistance"], 2),
            "MACD гист.": round(analysis["macd_hist"], 4),
            "BB ширина %": round(analysis["bb_width"], 1),
            "Stoch K": round(analysis["stoch_k"], 1),
        })

    result = pd.DataFrame(rows)
    if not result.empty:
        # Сортировка: сначала ЛОНГ, потом НЕЙТРАЛЬНО, потом ШОРТ
        signal_order = {"ЛОНГ": 0, "НЕЙТРАЛЬНО": 1, "ШОРТ": 2, "Нет данных": 3}
        result["_sort"] = result["Сигнал"].map(signal_order).fillna(3)
        result = result.sort_values(["_sort", "Сила"], ascending=[True, False])
        result = result.drop(columns=["_sort"])

    return result


def cluster_stocks(df: pd.DataFrame, n_clusters: int = 3) -> pd.DataFrame:
    """ML-кластеризация по техническим индикаторам."""
    from sklearn.preprocessing import StandardScaler
    from sklearn.cluster import KMeans

    features = ["RSI", "1М %", "Волат. %", "MACD гист.", "BB ширина %", "Stoch K"]
    df_clean = df.dropna(subset=features).copy()

    if len(df_clean) < n_clusters:
        df_clean["Категория"] = "Недостаточно данных"
        return df_clean

    X = df_clean[features].values
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=20)
    df_clean["Cluster"] = kmeans.fit_predict(X_scaled)

    # Именование по центрам кластеров
    cluster_names = {}
    for c in range(n_clusters):
        mask = df_clean["Cluster"] == c
        avg_rsi = df_clean.loc[mask, "RSI"].mean()
        avg_ret = df_clean.loc[mask, "1М %"].mean()
        avg_vol = df_clean.loc[mask, "Волат. %"].mean()
        avg_macd = df_clean.loc[mask, "MACD гист."].mean()

        # Логика именования по реальным индикаторам
        if avg_rsi > 60 and avg_ret > 5:
            name = "Перегретые лидеры (осторожно)"
        elif avg_rsi < 40 and avg_ret < -5:
            name = "Перепроданные (потенциал отскока)"
        elif avg_macd > 0 and avg_ret > 0:
            name = "Бычий тренд"
        elif avg_macd < 0 and avg_ret < 0:
            name = "Медвежий тренд"
        elif avg_vol > 35:
            name = "Высокая волатильность"
        elif avg_vol < 20:
            name = "Низкая волатильность"
        else:
            name = "Нейтральные"
        cluster_names[c] = name

    df_clean["Категория"] = df_clean["Cluster"].map(cluster_names)
    return df_clean