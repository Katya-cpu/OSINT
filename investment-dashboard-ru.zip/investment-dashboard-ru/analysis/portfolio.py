import pandas as pd
import numpy as np
from data.moex import get_candles

def calculate_portfolio(holdings: dict[str, float], days: int = 365) -> dict:
    """
    Расчёт метрик портфеля из акций MOEX.
    holdings: {"SBER": 100000, "GAZP": 50000} — суммы в рублях
    """
    tickers = list(holdings.keys())
    total = sum(holdings.values())
    weights = {t: v / total for t, v in holdings.items()}

    # Загрузка дневных свечей
    returns_df = pd.DataFrame()
    for t in tickers:
        candles = get_candles(t, interval=24, days=days)
        if not candles.empty and "close" in candles.columns:
            series = candles.set_index("date")["close"].pct_change()
            returns_df[t] = series

    returns_df = returns_df.dropna()

    if returns_df.empty or len(returns_df) < 10:
        return {"error": "Недостаточно данных"}

    w = pd.Series(weights).reindex(returns_df.columns).fillna(0)

    # Портфельная доходность
    port_returns = (returns_df * w).sum(axis=1)

    annual_return = port_returns.mean() * 252 * 100
    annual_vol = port_returns.std() * np.sqrt(252) * 100
    sharpe = annual_return / annual_vol if annual_vol > 0 else 0

    cumulative = (1 + port_returns).cumprod()
    max_dd = float(((cumulative / cumulative.cummax()) - 1).min() * 100)

    # Корреляция
    corr = returns_df.corr()

    # Метрики каждого актива
    asset_metrics = {}
    for t in returns_df.columns:
        ar = returns_df[t].mean() * 252 * 100
        av = returns_df[t].std() * np.sqrt(252) * 100
        asset_metrics[t] = {"доход_%": round(ar, 1), "волат_%": round(av, 1)}

    return {
        "total_value": total,
        "weights": {t: round(v * 100, 1) for t, v in weights.items()},
        "annual_return_%": round(annual_return, 2),
        "annual_volatility_%": round(annual_vol, 2),
        "sharpe_ratio": round(sharpe, 2),
        "max_drawdown_%": round(max_dd, 2),
        "correlation": corr,
        "asset_metrics": asset_metrics,
        "cumulative_returns": cumulative,
    }


def format_portfolio_for_llm(metrics: dict) -> str:
    if "error" in metrics:
        return metrics["error"]

    lines = [
        f"Общая стоимость: {metrics['total_value']:,.0f} руб.",
        f"Годовая доходность: {metrics['annual_return_%']}%",
        f"Годовая волатильность: {metrics['annual_volatility_%']}%",
        f"Sharpe Ratio: {metrics['sharpe_ratio']}",
        f"Max Drawdown: {metrics['max_drawdown_%']}%",
        "",
        "Распределение:",
    ]
    for t, w in metrics["weights"].items():
        am = metrics["asset_metrics"].get(t, {})
        lines.append(f"  {t}: {w}% (доход: {am.get('доход_%', '?')}%, волат: {am.get('волат_%', '?')}%)")

    return "\n".join(lines)