"""
ML Engine v2 — анализ российского фондового рынка.
GradientBoosting + макро-фичи + Monte Carlo + диагностика.
"""
import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier, IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import classification_report, confusion_matrix as sk_confusion_matrix
from analysis.indicators import (
    calc_rsi, calc_macd, calc_bollinger, calc_stochastic,
    calc_sma, calc_ema, calc_atr
)
from data.moex import get_candles
from config import MOEX_TICKERS, MOEX_SECTORS
# ============================================================
# НАЗВАНИЯ ФИЧЕЙ НА РУССКОМ
# ============================================================

FEATURE_NAMES_RU = {
    "return_1d": "Дневная доходность", "return_3d": "Доходность 3д",
    "return_5d": "Доходность 5д", "return_10d": "Доходность 10д",
    "return_20d": "Доходность 20д", "momentum_accel": "Ускорение momentum",
    "rsi_14": "RSI(14)", "rsi_7": "RSI(7)",
    "stoch_k": "Stochastic K", "stoch_d": "Stochastic D",
    "dist_sma5_%": "Расст. до SMA5", "dist_sma20_%": "Расст. до SMA20",
    "dist_sma50_%": "Расст. до SMA50",
    "sma5_above_20": "SMA5 > SMA20", "sma20_above_50": "SMA20 > SMA50",
    "macd_hist": "MACD гистограмма", "macd_hist_diff": "Изменение MACD",
    "atr_pct": "ATR %", "bb_position": "Позиция Bollinger",
    "bb_width": "Ширина Bollinger", "vol_5d": "Волат. 5д",
    "vol_20d": "Волат. 20д", "vol_ratio": "Отнош. волатильностей",
    "volume_ratio": "Объём / среднее", "body_pct": "Тело свечи %",
    "upper_shadow_pct": "Верхняя тень %", "lower_shadow_pct": "Нижняя тень %",
    "up_days_5": "Раст. дней из 5", "up_days_10": "Раст. дней из 10",
    "dist_20d_high_%": "Расст. до 20д макс", "dist_20d_low_%": "Расст. до 20д мин",
    "pattern_bull_engulf": "Бычье поглощение", "pattern_bear_engulf": "Медв. поглощение",
    "pattern_hammer": "Молот", "pattern_doji": "Доджи",
    "pattern_signal_5d": "Паттерн-сигнал 5д",
    "key_rate": "Ключевая ставка ЦБ",
    "usd_rub": "Курс USD/RUB",
    "usd_rub_change_5d": "Изм. USD/RUB за 5д",
}


# ============================================================
# МАКРОДАННЫЕ (из существующего data/cbr.py)
# ============================================================

def _load_macro_data(days: int = 1200) -> pd.DataFrame:
    """Загрузка ключевой ставки + USD/RUB из ЦБ."""
    try:
        from data.cbr import get_key_rate_history, get_currency_history
    except ImportError:
        return pd.DataFrame()

    macro_frames = []

    try:
        kr = get_key_rate_history()
        if not kr.empty:
            kr = kr[["date", "rate"]].copy()
            kr.columns = ["date", "key_rate"]
            kr["date"] = pd.to_datetime(kr["date"]).dt.normalize()
            macro_frames.append(kr)
    except Exception:
        pass

    try:
        usd = get_currency_history("USD", days=days)
        if not usd.empty:
            usd = usd[["date", "value"]].copy()
            usd.columns = ["date", "usd_rub"]
            usd["date"] = pd.to_datetime(usd["date"]).dt.normalize()
            macro_frames.append(usd)
    except Exception:
        pass

    if not macro_frames:
        return pd.DataFrame()

    result = macro_frames[0]
    for frame in macro_frames[1:]:
        result = pd.merge_asof(
            result.sort_values("date"),
            frame.sort_values("date"),
            on="date", direction="backward"
        )
    return result


# ============================================================
# ФИЧИ
# ============================================================

def _build_features(df: pd.DataFrame, macro_df: pd.DataFrame = None) -> pd.DataFrame:
    close = df["close"]
    high = df["high"]
    low = df["low"]
    volume = df["volume"] if "volume" in df.columns else pd.Series(0, index=df.index)

    feat = pd.DataFrame(index=df.index)

    feat["return_1d"] = close.pct_change(1)
    feat["return_3d"] = close.pct_change(3)
    feat["return_5d"] = close.pct_change(5)
    feat["return_10d"] = close.pct_change(10)
    feat["return_20d"] = close.pct_change(20)
    feat["momentum_accel"] = feat["return_5d"] - feat["return_20d"]

    feat["rsi_14"] = calc_rsi(close, 14)
    feat["rsi_7"] = calc_rsi(close, 7)
    stoch = calc_stochastic(high, low, close, 14, 3)
    feat["stoch_k"] = stoch["k"]
    feat["stoch_d"] = stoch["d"]

    sma_5 = calc_sma(close, 5)
    sma_20 = calc_sma(close, 20)
    sma_50 = calc_sma(close, 50)
    feat["dist_sma5_%"] = (close - sma_5) / sma_5 * 100
    feat["dist_sma20_%"] = (close - sma_20) / sma_20 * 100
    feat["dist_sma50_%"] = (close - sma_50) / sma_50 * 100
    feat["sma5_above_20"] = (sma_5 > sma_20).astype(int)
    feat["sma20_above_50"] = (sma_20 > sma_50).astype(int)

    macd = calc_macd(close)
    feat["macd_hist"] = macd["histogram"]
    feat["macd_hist_diff"] = feat["macd_hist"].diff()

    feat["atr_pct"] = calc_atr(high, low, close, 14) / close * 100
    bb = calc_bollinger(close, 20)
    feat["bb_position"] = (close - bb["lower"]) / (bb["upper"] - bb["lower"])
    feat["bb_width"] = bb["width"]
    feat["vol_5d"] = close.pct_change().rolling(5).std() * np.sqrt(252) * 100
    feat["vol_20d"] = close.pct_change().rolling(20).std() * np.sqrt(252) * 100
    feat["vol_ratio"] = feat["vol_5d"] / feat["vol_20d"].replace(0, np.nan)

    if volume.sum() > 0:
        vol_sma = calc_sma(volume, 20)
        feat["volume_ratio"] = volume / vol_sma.replace(0, np.nan)
    else:
        feat["volume_ratio"] = 1.0

    feat["body_pct"] = (close - df["open"]) / df["open"] * 100
    feat["upper_shadow_pct"] = (high - pd.concat([close, df["open"]], axis=1).max(axis=1)) / close * 100
    feat["lower_shadow_pct"] = (pd.concat([close, df["open"]], axis=1).min(axis=1) - low) / close * 100
    feat["up_days_5"] = (close.diff() > 0).rolling(5).sum()
    feat["up_days_10"] = (close.diff() > 0).rolling(10).sum()

    feat["dist_20d_high_%"] = (close - high.rolling(20).max()) / close * 100
    feat["dist_20d_low_%"] = (close - low.rolling(20).min()) / close * 100

    # Свечные паттерны
    o = df["open"].values
    h_arr, l_arr, c_arr = high.values, low.values, close.values
    body = c_arr - o
    body_abs = np.abs(body)
    upper_shadow = h_arr - np.maximum(o, c_arr)
    lower_shadow = np.minimum(o, c_arr) - l_arr
    candle_range = h_arr - l_arr

    bull_engulf = np.zeros(len(df))
    bear_engulf = np.zeros(len(df))
    hammer_arr = np.zeros(len(df))
    doji_arr = np.zeros(len(df))

    for i in range(2, len(df)):
        if body[i-1] < 0 and body[i] > 0 and o[i] <= c_arr[i-1] and c_arr[i] >= o[i-1]:
            bull_engulf[i] = 1
        if body[i-1] > 0 and body[i] < 0 and o[i] >= c_arr[i-1] and c_arr[i] <= o[i-1]:
            bear_engulf[i] = 1
        if body_abs[i] > 0 and lower_shadow[i] >= body_abs[i] * 2 and upper_shadow[i] < body_abs[i] * 0.5:
            hammer_arr[i] = 1
        if candle_range[i] > 0 and body_abs[i] / candle_range[i] < 0.1:
            doji_arr[i] = 1

    feat["pattern_bull_engulf"] = bull_engulf
    feat["pattern_bear_engulf"] = bear_engulf
    feat["pattern_hammer"] = hammer_arr
    feat["pattern_doji"] = doji_arr

    bull_p = pd.Series(bull_engulf + hammer_arr, index=df.index)
    bear_p = pd.Series(bear_engulf, index=df.index)
    feat["pattern_signal_5d"] = bull_p.rolling(5).sum() - bear_p.rolling(5).sum()

    # === МАКРО-ФИЧИ ===
    if macro_df is not None and not macro_df.empty and "date" in df.columns:
        try:
            candle_dates = pd.DataFrame({
                "_idx": df.index,
                "date": pd.to_datetime(df["date"]).dt.normalize(),
            }).sort_values("date")

            macro_clean = macro_df.copy()
            macro_clean["date"] = pd.to_datetime(macro_clean["date"]).dt.normalize()
            macro_clean = macro_clean.sort_values("date").drop_duplicates("date", keep="last")

            merged = pd.merge_asof(candle_dates, macro_clean, on="date", direction="backward")
            merged = merged.set_index("_idx").sort_index()

            if "key_rate" in merged.columns:
                feat["key_rate"] = merged["key_rate"].values
            if "usd_rub" in merged.columns:
                feat["usd_rub"] = merged["usd_rub"].values
                feat["usd_rub_change_5d"] = pd.Series(
                    merged["usd_rub"].values, index=feat.index
                ).pct_change(5)
        except Exception:
            pass

    return feat


# ============================================================
# МОДЕЛЬ
# ============================================================

class MarketModel:
    """
    GradientBoosting на всех акциях MOEX.
    Гиперпараметры настраиваются через интерфейс.
    """

    # Дефолтные гиперпараметры
    DEFAULT_PARAMS = {
        "n_estimators": 500,
        "max_depth": 4,
        "learning_rate": 0.03,
        "min_samples_leaf": 50,
        "subsample": 0.8,
        "max_features": 0.6,
        "target_threshold": 0.005,
    }

    def __init__(self):
        self.model = None
        self.scaler = None
        self.feature_cols = None
        self.accuracy = None
        self.report = None
        self.feature_importance = None
        self.is_trained = False
        self.train_size = 0
        self.market_insights = None
        self.diagnostics = None
        self.params = dict(self.DEFAULT_PARAMS)

    def train(self, tickers: list = None, days: int = 1000,
              progress_callback=None, params: dict = None) -> dict:
        """
        Обучение модели.
        params: dict гиперпараметров (если None — используются текущие self.params)
        """
        if tickers is None:
            tickers = MOEX_TICKERS

        if params:
            self.params.update(params)

        target_threshold = self.params.get("target_threshold", 0.005)

        # Загрузка макроданных
        if progress_callback:
            progress_callback(0, "Загрузка макроданных (ключевая ставка, USD/RUB)...")
        macro_df = _load_macro_data(days + 200)

        all_data = []
        loaded = 0

        for i, ticker in enumerate(tickers):
            if progress_callback:
                progress_callback(
                    (i / len(tickers)) * 0.8,
                    f"Загрузка {ticker} ({i+1}/{len(tickers)})"
                )

            candles = get_candles(ticker, interval=24, days=days)
            if candles.empty or "close" not in candles.columns or len(candles) < 100:
                continue

            features = _build_features(candles, macro_df)

            # Целевая: средняя цена следующих 5 дней vs текущая
            future_avg = candles["close"].shift(-1).rolling(5).mean().shift(-4)
            future_return = future_avg / candles["close"] - 1

            # Фильтрация шума: только чёткие движения > порога
            features["target"] = np.where(
                future_return > target_threshold, 1,
                np.where(future_return < -target_threshold, 0, np.nan)
            )
            features["ticker"] = ticker
            features["sector"] = MOEX_SECTORS.get(ticker, "Другое")

            all_data.append(features)
            loaded += 1

        if not all_data:
            return {"error": "Не удалось загрузить данные ни по одному тикеру"}

        if progress_callback:
            progress_callback(0.8, "Подготовка данных и обучение...")

        df = pd.concat(all_data, ignore_index=True)

        # Секторный one-hot
        sector_dummies = pd.get_dummies(df["sector"], prefix="sector")
        df = pd.concat([df, sector_dummies], axis=1)

        drop_cols = ["target", "ticker", "sector"]
        feature_cols = [c for c in df.columns if c not in drop_cols]

        total_before = len(df.dropna(subset=feature_cols))
        df_clean = df.dropna(subset=feature_cols + ["target"])
        samples_filtered = total_before - len(df_clean)
        self.train_size = len(df_clean)

        if self.train_size < 500:
            return {"error": f"Мало данных после фильтрации: {self.train_size} строк"}

        X = df_clean[feature_cols].values
        y = df_clean["target"].values

        # Проверка: target не должен быть константой
        unique_targets = np.unique(y)
        if len(unique_targets) < 2:
            return {"error": "Нет вариативности в целевой переменной (все значения одинаковы)"}

        tscv = TimeSeriesSplit(n_splits=5)

        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X)

        self.model = GradientBoostingClassifier(
            n_estimators=int(self.params["n_estimators"]),
            max_depth=int(self.params["max_depth"]),
            learning_rate=float(self.params["learning_rate"]),
            min_samples_leaf=int(self.params["min_samples_leaf"]),
            min_samples_split=int(self.params["min_samples_leaf"]) * 2,
            subsample=float(self.params["subsample"]),
            max_features=float(self.params["max_features"]),
            random_state=42,
        )

        # CV с полной диагностикой
        fold_details = []
        last_cm = None
        last_report = None

        for fold_idx, (train_idx, val_idx) in enumerate(tscv.split(X_scaled)):
            X_tr, X_val = X_scaled[train_idx], X_scaled[val_idx]
            y_tr, y_val = y[train_idx], y[val_idx]

            # Проверка: фолд должен иметь оба класса
            if len(np.unique(y_tr)) < 2:
                continue

            self.model.fit(X_tr, y_tr)

            train_acc = self.model.score(X_tr, y_tr) * 100
            val_acc = self.model.score(X_val, y_val) * 100

            y_pred = self.model.predict(X_val)
            last_cm = sk_confusion_matrix(y_val, y_pred)
            last_report = classification_report(
                y_val, y_pred, output_dict=True,
                target_names=["Падение", "Рост"]
            )

            fold_details.append({
                "Фолд": fold_idx + 1,
                "Train строк": len(train_idx),
                "Val строк": len(val_idx),
                "Train Acc %": round(train_acc, 1),
                "Val Acc %": round(val_acc, 1),
                "Разрыв %": round(train_acc - val_acc, 1),
            })

        if not fold_details:
            return {"error": "Ни один фолд CV не содержал оба класса. Попробуйте изменить порог шума."}

        # Финальное обучение на всех данных
        self.model.fit(X_scaled, y)

        # Проверка: все деревья в модели валидны
        model_valid = True
        for stage in self.model.estimators_:
            for tree in stage:
                if tree is None or not hasattr(tree, 'tree_') or tree.tree_ is None:
                    model_valid = False
                    break
            if not model_valid:
                break

        if not model_valid:
            self.is_trained = False
            return {"error": "Модель не смогла полностью обучиться. Попробуйте уменьшить n_estimators или увеличить данные."}

        final_train_acc = self.model.score(X_scaled, y) * 100

        self.feature_cols = feature_cols

        train_accs = [f["Train Acc %"] for f in fold_details]
        val_accs = [f["Val Acc %"] for f in fold_details]
        self.accuracy = round(np.mean(val_accs), 1)
        self.report = last_report
        self.is_trained = True

        # Feature importance
        importances = pd.Series(self.model.feature_importances_, index=feature_cols)
        self.feature_importance = importances.nlargest(20)

        # Инсайты
        self.market_insights = self._extract_insights(df_clean, feature_cols)

        # Полная диагностика
        overfit_gap = round(np.mean(train_accs) - np.mean(val_accs), 1)

        self.diagnostics = {
            "fold_details": fold_details,
            "confusion_matrix": last_cm.tolist() if last_cm is not None else None,
            "classification_report": last_report,
            "train_accuracy": round(np.mean(train_accs), 1),
            "final_train_accuracy": round(final_train_acc, 1),
            "val_accuracy": self.accuracy,
            "overfit_gap": overfit_gap,
            "class_balance": f"{y.mean()*100:.0f}% рост / {(1-y.mean())*100:.0f}% падение",
            "target_threshold": target_threshold,
            "total_samples": self.train_size,
            "total_before_filter": total_before,
            "samples_filtered": samples_filtered,
            "tickers_loaded": loaded,
            "n_features": len(feature_cols),
            "model_params": dict(self.params),
            # Диагноз
            "health": _diagnose_model(overfit_gap, self.accuracy),
        }

        if progress_callback:
            progress_callback(1.0, "Обучение завершено!")

        return {
            "accuracy": self.accuracy,
            "train_accuracy": round(np.mean(train_accs), 1),
            "train_size": self.train_size,
            "tickers_loaded": loaded,
            "class_balance": self.diagnostics["class_balance"],
            "cv_scores": val_accs,
            "overfit_gap": overfit_gap,
            "samples_filtered": samples_filtered,
        }

    def _default_prediction(self, ticker: str, reason: str = "Ошибка") -> dict:
        """Возвращает нейтральное предсказание при невозможности прогноза."""
        return {
            "prediction": "Неопределённо",
            "confidence": "Нет данных",
            "prob_up": 50.0,
            "prob_down": 50.0,
            "model_accuracy": self.accuracy,
            "explanations": [],
            "train_size": self.train_size,
            "error": reason,
        }

    def predict_ticker(self, ticker: str, days: int = 1000) -> dict:
        if not self.is_trained:
            return {"error": "Модель не обучена. Нажмите 'Обучить модель'."}

        candles = get_candles(ticker, interval=24, days=days)
        if candles.empty or "close" not in candles.columns or len(candles) < 60:
            return self._default_prediction(ticker, f"Мало данных для {ticker}")

        try:
            macro_df = _load_macro_data(days + 200)
            features = _build_features(candles, macro_df)
            sector = MOEX_SECTORS.get(ticker, "Другое")

            for col in self.feature_cols:
                if col.startswith("sector_") and col not in features.columns:
                    features[col] = 0
            sector_col = f"sector_{sector}"
            if sector_col in features.columns:
                features[sector_col] = 1

            last_row = features.iloc[-1:].copy()
            missing_cols = [c for c in self.feature_cols if c not in features.columns]
            for c in missing_cols:
                last_row[c] = 0

            last_row = last_row[self.feature_cols]
            if last_row.isna().any(axis=1).iloc[0]:
                last_row = last_row.fillna(0)

            X = self.scaler.transform(last_row.values)

            # Проверка валидности деревьев перед predict
            for stage in self.model.estimators_:
                for tree in stage:
                    if tree is None or not hasattr(tree, 'tree_') or tree.tree_ is None:
                        return self._default_prediction(ticker, "Модель повреждена. Переобучите модель.")

            proba = self.model.predict_proba(X)[0]
            prob_up = float(proba[1]) if len(proba) > 1 else 0.5

            explanations = _explain_prediction(
                features.iloc[-1], self.feature_cols, self.feature_importance
            )

            if prob_up > 0.65:
                prediction, confidence = "РОСТ", "Высокая"
            elif prob_up > 0.55:
                prediction, confidence = "Скорее рост", "Умеренная"
            elif prob_up < 0.35:
                prediction, confidence = "ПАДЕНИЕ", "Высокая"
            elif prob_up < 0.45:
                prediction, confidence = "Скорее падение", "Умеренная"
            else:
                prediction, confidence = "Неопределённо", "Низкая"

            return {
                "prediction": prediction,
                "confidence": confidence,
                "prob_up": round(prob_up * 100, 1),
                "prob_down": round((1 - prob_up) * 100, 1),
                "model_accuracy": self.accuracy,
                "explanations": explanations,
                "train_size": self.train_size,
            }

        except Exception as e:
            return self._default_prediction(ticker, str(e))

    def predict_all(self, tickers: list = None, days: int = 1000) -> pd.DataFrame:
        if not self.is_trained:
            return pd.DataFrame()
        if tickers is None:
            tickers = MOEX_TICKERS

        rows = []
        for ticker in tickers:
            result = self.predict_ticker(ticker, days)
            if "error" in result:
                continue
            rows.append({
                "Тикер": ticker,
                "Сектор": MOEX_SECTORS.get(ticker, "Другое"),
                "Прогноз": result["prediction"],
                "Вероятн. роста %": result["prob_up"],
                "Уверенность": result["confidence"],
            })
        return pd.DataFrame(rows).sort_values("Вероятн. роста %", ascending=False)

    def get_market_recommendations(self) -> dict:
        if not self.is_trained:
            return {"error": "Модель не обучена"}

        predictions = self.predict_all()
        if predictions.empty:
            return {"error": "Нет данных"}

        buy = predictions[predictions["Вероятн. роста %"] > 60]
        sell = predictions[predictions["Вероятн. роста %"] < 40]
        hold = predictions[
            (predictions["Вероятн. роста %"] >= 40) &
            (predictions["Вероятн. роста %"] <= 60)
        ]

        sector_avg = predictions.groupby("Сектор")["Вероятн. роста %"].mean()

        return {
            "buy": buy[["Тикер", "Сектор", "Вероятн. роста %"]].to_dict("records"),
            "sell": sell[["Тикер", "Сектор", "Вероятн. роста %"]].to_dict("records"),
            "hold": hold[["Тикер", "Сектор", "Вероятн. роста %"]].to_dict("records"),
            "best_sectors": sector_avg.nlargest(3).to_dict(),
            "worst_sectors": sector_avg.nsmallest(3).to_dict(),
            "market_avg": round(predictions["Вероятн. роста %"].mean(), 1),
            "total": len(predictions),
        }

    def get_diagnostics(self) -> dict:
        if not self.diagnostics:
            return {}
        return self.diagnostics

    def _extract_insights(self, df, feature_cols) -> list:
        insights = []
        importances = pd.Series(self.model.feature_importances_, index=feature_cols)
        top = importances.nlargest(5)

        for feat_name, imp in top.items():
            ru_name = FEATURE_NAMES_RU.get(feat_name, feat_name)
            if feat_name in df.columns:
                grow = df[df["target"] == 1][feat_name].mean()
                fall = df[df["target"] == 0][feat_name].mean()
                if abs(grow - fall) > 0.01:
                    direction = "выше" if grow > fall else "ниже"
                    insights.append(
                        f"<strong>{ru_name}</strong> (важность {imp*100:.1f}%): "
                        f"перед ростом значение {direction} "
                        f"(рост: {grow:.2f}, падение: {fall:.2f})"
                    )
        return insights


# ============================================================
# ДИАГНОЗ МОДЕЛИ
# ============================================================

def _diagnose_model(overfit_gap: float, val_accuracy: float) -> dict:
    """Автоматический диагноз состояния модели."""
    if overfit_gap > 20:
        status = "ПЕРЕОБУЧЕНИЕ (сильное)"
        color = "red"
        advice = (
            "Модель запомнила обучающие данные. Рекомендации: "
            "уменьшить max_depth (до 3), увеличить min_samples_leaf (до 80), "
            "уменьшить n_estimators (до 300)."
        )
    elif overfit_gap > 10:
        status = "ПЕРЕОБУЧЕНИЕ (умеренное)"
        color = "orange"
        advice = (
            "Модель немного переобучена. Попробуйте: "
            "уменьшить max_depth на 1, увеличить min_samples_leaf на 10-20."
        )
    elif val_accuracy < 52:
        status = "НЕДООБУЧЕНИЕ"
        color = "orange"
        advice = (
            "Модель не находит закономерностей. Попробуйте: "
            "увеличить max_depth (до 5-6), уменьшить min_samples_leaf (до 30), "
            "увеличить n_estimators (до 700), уменьшить target_threshold (до 0.003)."
        )
    elif val_accuracy < 55:
        status = "СЛАБЫЙ СИГНАЛ"
        color = "yellow"
        advice = (
            "Модель работает чуть лучше случайности. Это нормально для фондового рынка. "
            "Используйте прогнозы только с высокой уверенностью (>60%)."
        )
    elif overfit_gap < 5 and val_accuracy >= 55:
        status = "ХОРОШО"
        color = "green"
        advice = (
            "Модель сбалансирована. Разрыв train/val небольшой, "
            "accuracy выше случайного угадывания."
        )
    else:
        status = "НОРМАЛЬНО"
        color = "green"
        advice = "Модель работает адекватно. Можно пробовать улучшить параметры."

    return {"status": status, "color": color, "advice": advice}


# ============================================================
# MONTE CARLO ПРОГНОЗ
# ============================================================

def monte_carlo_forecast(close: pd.Series, days_ahead: int = 5,
                          n_sims: int = 1000, ml_bias: float = 0.0,
                          seed: int = 42) -> dict:
    """
    Monte Carlo симуляция цены.
    Мгновенный расчёт: 1000 симуляций x 10 дней < 1 секунда.
    """
    rng = np.random.default_rng(seed)
    returns = close.pct_change().dropna()

    mu = float(returns.mean()) + ml_bias
    sigma = float(returns.std())
    last_price = float(close.iloc[-1])

    random_returns = rng.normal(mu, sigma, (n_sims, days_ahead))
    price_paths = last_price * np.cumprod(1 + random_returns, axis=1)
    price_paths = np.column_stack([np.full(n_sims, last_price), price_paths])

    median_final = float(np.median(price_paths[:, -1]))

    return {
        "paths": price_paths,
        "p5": np.percentile(price_paths, 5, axis=0),
        "p10": np.percentile(price_paths, 10, axis=0),
        "p25": np.percentile(price_paths, 25, axis=0),
        "p50": np.percentile(price_paths, 50, axis=0),
        "p75": np.percentile(price_paths, 75, axis=0),
        "p90": np.percentile(price_paths, 90, axis=0),
        "p95": np.percentile(price_paths, 95, axis=0),
        "mean": price_paths.mean(axis=0),
        "last_price": last_price,
        "expected_return": round((median_final / last_price - 1) * 100, 2),
        "prob_above_current": round(
            float((price_paths[:, -1] > last_price).mean()) * 100, 1
        ),
    }


# ============================================================
# ОБЪЯСНЕНИЕ ПРОГНОЗА
# ============================================================

def _explain_prediction(last_row, feature_cols, importance):
    explanations = []
    top_feats = importance.head(10)

    for feat_name, imp in top_feats.items():
        if feat_name not in last_row or pd.isna(last_row[feat_name]):
            continue
        if feat_name.startswith("sector_"):
            continue

        v = float(last_row[feat_name])
        ru_name = FEATURE_NAMES_RU.get(feat_name, feat_name)
        text = _describe_value(feat_name, v)
        if text:
            explanations.append(f"<strong>{ru_name}</strong> (вес {imp*100:.1f}%): {text}")

    return explanations


def _describe_value(name, v):
    if name in ("rsi_14", "rsi_7"):
        if v < 30: return f"{v:.0f} — перепроданность"
        if v > 70: return f"{v:.0f} — перекупленность"
        return f"{v:.0f} — нейтрально"

    if name == "bb_position":
        if v < 0.15: return f"{v:.0%} — у нижней границы"
        if v > 0.85: return f"{v:.0%} — у верхней границы"
        return f"{v:.0%} — в середине канала"

    if name.startswith("return_") or name == "momentum_accel":
        return f"{v*100:+.1f}%"

    if name.startswith("dist_sma"):
        side = "выше" if v > 0 else "ниже"
        return f"цена {side} на {abs(v):.1f}%"

    if name == "macd_hist":
        return f"{v:.4f} — {'бычий' if v > 0 else 'медвежий'} импульс"

    if name == "volume_ratio":
        if v > 2: return f"{v:.1f}x — аномально высокий объём"
        if v < 0.5: return f"{v:.1f}x — низкий объём"
        return f"{v:.1f}x — нормальный"

    if name == "up_days_5":
        return f"{v:.0f} из 5"

    if name == "vol_ratio":
        if v > 1.3: return f"{v:.2f} — волатильность растёт"
        if v < 0.7: return f"{v:.2f} — волатильность сжимается"
        return f"{v:.2f} — стабильная"

    if name == "key_rate":
        if v >= 15: return f"{v:.1f}% — высокая (давление на акции)"
        if v >= 10: return f"{v:.1f}% — умеренная"
        return f"{v:.1f}% — низкая (позитив для акций)"

    if name == "usd_rub":
        return f"{v:.2f} руб."

    if name == "usd_rub_change_5d":
        return f"{v*100:+.2f}% {'ослабление рубля' if v > 0 else 'укрепление рубля'}"

    return f"{v:.4f}"


# ============================================================
# СИГНАЛЬНАЯ СИСТЕМА (правила, НЕ ML)
# ============================================================

def compute_signal(df: pd.DataFrame) -> dict:
    """Сигнал на основе правил (голосование индикаторов). Это НЕ ML."""
    if len(df) < 60:
        return {"error": "Нужно минимум 60 свечей"}

    features = _build_features(df)
    last = features.iloc[-1]
    votes = []

    rsi = _safe(last, "rsi_14", 50)
    if rsi < 25:
        votes.append(("RSI", +2, f"RSI={rsi:.0f} — сильная перепроданность"))
    elif rsi < 35:
        votes.append(("RSI", +1, f"RSI={rsi:.0f} — умеренная перепроданность"))
    elif rsi > 75:
        votes.append(("RSI", -2, f"RSI={rsi:.0f} — сильная перекупленность"))
    elif rsi > 65:
        votes.append(("RSI", -1, f"RSI={rsi:.0f} — приближается к перекупленности"))
    else:
        votes.append(("RSI", 0, f"RSI={rsi:.0f} — нейтрально"))

    macd_h = _safe(last, "macd_hist", 0)
    macd_d = _safe(last, "macd_hist_diff", 0)
    if macd_h > 0 and macd_d > 0:
        votes.append(("MACD", +2, "Бычий импульс набирает силу"))
    elif macd_h > 0 and macd_d < 0:
        votes.append(("MACD", 0, "Бычий импульс ослабевает"))
    elif macd_h < 0 and macd_d > 0:
        votes.append(("MACD", +1, "Медвежий ослабевает — потенциал разворота"))
    elif macd_h < 0 and macd_d < 0:
        votes.append(("MACD", -2, "Медвежий импульс усиливается"))

    dist20 = _safe(last, "dist_sma20_%", 0)
    dist50 = _safe(last, "dist_sma50_%", 0)
    sma_cross = _safe(last, "sma20_above_50", 0)
    if dist20 > 0 and dist50 > 0 and sma_cross:
        votes.append(("Тренд", +2, f"Все SMA подтверждают рост (+{dist20:.1f}%)"))
    elif dist20 < 0 and dist50 < 0 and not sma_cross:
        votes.append(("Тренд", -2, f"Все SMA подтверждают падение ({dist20:.1f}%)"))
    elif dist20 > 0:
        votes.append(("Тренд", +1, "Цена выше SMA20, ниже SMA50"))
    else:
        votes.append(("Тренд", -1, "Цена ниже SMA20"))

    bb_pos = _safe(last, "bb_position", 0.5)
    if bb_pos < 0.1:
        votes.append(("Bollinger", +2, f"У нижней границы ({bb_pos:.0%})"))
    elif bb_pos > 0.9:
        votes.append(("Bollinger", -2, f"У верхней границы ({bb_pos:.0%})"))
    elif bb_pos < 0.25:
        votes.append(("Bollinger", +1, f"В нижней четверти ({bb_pos:.0%})"))
    elif bb_pos > 0.75:
        votes.append(("Bollinger", -1, f"В верхней четверти ({bb_pos:.0%})"))

    stoch_k = _safe(last, "stoch_k", 50)
    if stoch_k < 20:
        votes.append(("Stochastic", +2, f"K={stoch_k:.0f} — перепроданность"))
    elif stoch_k > 80:
        votes.append(("Stochastic", -2, f"K={stoch_k:.0f} — перекупленность"))

    pat = _safe(last, "pattern_signal_5d", 0)
    if pat >= 2:
        votes.append(("Паттерны", +2, "Сильные бычьи паттерны"))
    elif pat >= 1:
        votes.append(("Паттерны", +1, "Слабый бычий сигнал"))
    elif pat <= -2:
        votes.append(("Паттерны", -2, "Сильные медвежьи паттерны"))
    elif pat <= -1:
        votes.append(("Паттерны", -1, "Слабый медвежий сигнал"))

    up_days = _safe(last, "up_days_5", 2.5)
    if up_days >= 4:
        votes.append(("Серия", +1, f"{up_days:.0f}/5 дней роста"))
    elif up_days <= 1:
        votes.append(("Серия", -1, f"{up_days:.0f}/5 дней роста"))

    total_bull = sum(v[1] for v in votes if v[1] > 0)
    total_bear = sum(abs(v[1]) for v in votes if v[1] < 0)
    net_score = sum(v[1] for v in votes)
    total_abs = total_bull + total_bear
    pct_bull = total_bull / total_abs * 100 if total_abs > 0 else 50
    pct_bear = total_bear / total_abs * 100 if total_abs > 0 else 50

    if net_score >= 6:
        signal, desc = "СИЛЬНЫЙ ЛОНГ", "Подавляющее большинство бычьи"
    elif net_score >= 3:
        signal, desc = "ЛОНГ", "Преобладают бычьи сигналы"
    elif net_score <= -6:
        signal, desc = "СИЛЬНЫЙ ШОРТ", "Подавляющее большинство медвежьи"
    elif net_score <= -3:
        signal, desc = "ШОРТ", "Преобладают медвежьи сигналы"
    else:
        signal, desc = "НЕЙТРАЛЬНО", "Сигналы противоречивы"

    return {
        "signal": signal, "signal_description": desc,
        "net_score": net_score, "pct_bull": round(pct_bull, 1),
        "pct_bear": round(pct_bear, 1), "total_bull": total_bull,
        "total_bear": total_bear, "votes": votes,
    }


def _safe(row, key, default=0):
    val = row.get(key)
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return default
    return float(val)


# ============================================================
# АНОМАЛИИ (с объяснением через z-score)
# ============================================================

def detect_anomalies(df: pd.DataFrame) -> dict:
    if len(df) < 60:
        return {"is_anomaly": False, "reasons": [], "explanation": ""}

    features = _build_features(df)
    keys = ["return_1d", "volume_ratio", "atr_pct", "bb_position", "rsi_14", "macd_hist"]
    available = [f for f in keys if f in features.columns]
    data = features[available].dropna()

    if len(data) < 30:
        return {"is_anomaly": False, "reasons": [], "explanation": ""}

    X = StandardScaler().fit_transform(data.values)
    iso = IsolationForest(contamination=0.05, random_state=42, n_estimators=200)
    scores = iso.fit_predict(X)

    is_anom = scores[-1] == -1

    # Объяснение: какие именно показатели отклоняются
    reasons = []
    if is_anom:
        last_values = data.iloc[-1]
        means = data.mean()
        stds = data.std()

        for col in available:
            if stds[col] == 0:
                continue
            z = (last_values[col] - means[col]) / stds[col]
            if abs(z) > 1.8:
                ru_name = FEATURE_NAMES_RU.get(col, col)
                direction = "выше" if z > 0 else "ниже"
                reasons.append(
                    f"{ru_name}: {last_values[col]:.2f} "
                    f"({direction} нормы на {abs(z):.1f} сигм)"
                )

        if not reasons:
            reasons.append("Необычная комбинация нескольких показателей одновременно")

    return {
        "is_anomaly": is_anom,
        "anomaly_score": round(float(iso.score_samples(X[-1:])[0]), 3),
        "reasons": reasons,
        "explanation": "; ".join(reasons) if reasons else "",
        "anomaly_days_20": int((scores[-20:] == -1).sum()) if len(scores) >= 20 else 0,
    }


# ============================================================
# РЕЖИМ РЫНКА
# ============================================================

def detect_regime(df: pd.DataFrame) -> dict:
    if len(df) < 60:
        return {"regime": "Мало данных", "details": {}, "explanation": "",
                "additional": [], "trend_score": 0, "volatility_score": 0}
    features = _build_features(df)
    last = features.iloc[-1]
    ts, vs = 0, 0
    details = {}

    d20, d50 = _safe(last, "dist_sma20_%"), _safe(last, "dist_sma50_%")
    if d20 > 0 and d50 > 0:
        ts += 2; details["SMA"] = "Выше SMA20 и SMA50"
    elif d20 < 0 and d50 < 0:
        ts -= 2; details["SMA"] = "Ниже SMA20 и SMA50"
    else:
        details["SMA"] = "Между SMA20 и SMA50"

    r5, r20 = _safe(last, "return_5d"), _safe(last, "return_20d")
    if r5 > 0.02 and r20 > 0.03:
        ts += 2; details["Momentum"] = f"+{r5*100:.1f}%/5д, +{r20*100:.1f}%/20д"
    elif r5 < -0.02 and r20 < -0.03:
        ts -= 2; details["Momentum"] = f"{r5*100:.1f}%/5д, {r20*100:.1f}%/20д"
    else:
        details["Momentum"] = f"{r5*100:+.1f}%/5д, {r20*100:+.1f}%/20д"

    mh, md = _safe(last, "macd_hist"), _safe(last, "macd_hist_diff")
    if mh > 0 and md > 0:
        ts += 1; details["MACD"] = "Бычья гистограмма растёт"
    elif mh < 0 and md < 0:
        ts -= 1; details["MACD"] = "Медвежья углубляется"
    elif mh < 0 and md > 0:
        details["MACD"] = "Медвежий ослабевает"
    elif mh > 0 and md < 0:
        details["MACD"] = "Бычий ослабевает"

    vr = _safe(last, "vol_ratio", 1.0)
    if vr > 1.3:
        vs += 2; details["Волатильность"] = f"Растёт ({vr:.2f})"
    elif vr < 0.7:
        details["Волатильность"] = f"Сжимается ({vr:.2f})"
    else:
        details["Волатильность"] = "Стабильная"

    pat = _safe(last, "pattern_signal_5d")
    if pat >= 2:
        ts += 1; details["Паттерны"] = f"Бычьи ({pat:.0f})"
    elif pat <= -2:
        ts -= 1; details["Паттерны"] = f"Медвежьи ({abs(pat):.0f})"

    if vs >= 2 and abs(ts) < 2:
        reg, exp = "Высокая волатильность", "Нестабильность"
    elif ts >= 3:
        reg, exp = "Устойчивый рост", "Все индикаторы вверх"
    elif ts <= -3:
        reg, exp = "Устойчивое падение", "Все индикаторы вниз"
    elif 1 <= ts <= 2:
        reg, exp = "Умеренный рост", "Тенденция вверх"
    elif -2 <= ts <= -1:
        reg, exp = "Умеренное падение", "Тенденция вниз"
    else:
        reg, exp = "Боковик", "Нет направления"

    return {"regime": reg, "trend_score": ts, "volatility_score": vs,
            "details": details, "explanation": exp, "additional": []}


# ============================================================
# СКОРИНГ ПРИВЛЕКАТЕЛЬНОСТИ
# ============================================================

def score_attractiveness(analysis, signal_data, anomaly, regime):
    score = 50
    reasons, breakdown = [], {}

    pct_bull = signal_data.get("pct_bull", 50)
    net = signal_data.get("net_score", 0)
    sc = max(-20, min(20, net * 3))
    score += sc; breakdown["Индикаторы"] = round(sc, 1)
    reasons.append(f"Индикаторы: {pct_bull:.0f}% бычьих ({signal_data.get('signal', '?')})")

    rsi = analysis.get("rsi", 50)
    if rsi < 30:
        s = 10; reasons.append(f"RSI={rsi:.0f}: перепроданность")
    elif rsi > 70:
        s = -10; reasons.append(f"RSI={rsi:.0f}: перекупленность")
    else:
        s = 0
    score += s; breakdown["RSI"] = s

    t = regime.get("trend_score", 0)
    tc = max(-12, min(12, t * 3))
    score += tc; breakdown["Тренд"] = tc
    reasons.append(f"Режим: {regime.get('regime', '?')}")

    if anomaly.get("is_anomaly"):
        rw = analysis.get("return_1w", 0)
        if rw < -0.03:
            score += 5; breakdown["Аномалия"] = 5
        elif rw > 0.03:
            score -= 5; breakdown["Аномалия"] = -5

    score = max(0, min(100, score))
    if score >= 70:
        cat, summ = "Привлекательная", "Большинство за рост"
    elif score >= 55:
        cat, summ = "Умеренно привлекательная", "Есть положительные сигналы"
    elif score >= 45:
        cat, summ = "Нейтральная", "Противоречивые сигналы"
    elif score >= 30:
        cat, summ = "Непривлекательная", "Преобладают негативные"
    else:
        cat, summ = "Избегать", "Индикаторы за снижение"

    return {"score": round(score), "category": cat, "summary": summ,
            "reasons": reasons, "breakdown": breakdown}


# Глобальный экземпляр
market_model = MarketModel()