import pandas as pd
import numpy as np

def calc_sma(series: pd.Series, period: int) -> pd.Series:
    return series.rolling(window=period).mean()


def calc_ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()


def calc_rsi(series: pd.Series, period: int = 14) -> pd.Series:
    """RSI — Relative Strength Index."""
    delta = series.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = -delta.where(delta < 0, 0.0)
    avg_gain = gain.ewm(alpha=1/period, min_periods=period).mean()
    avg_loss = loss.ewm(alpha=1/period, min_periods=period).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    return rsi


def calc_macd(series: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> dict:
    """MACD — Moving Average Convergence Divergence."""
    ema_fast = calc_ema(series, fast)
    ema_slow = calc_ema(series, slow)
    macd_line = ema_fast - ema_slow
    signal_line = calc_ema(macd_line, signal)
    histogram = macd_line - signal_line
    return {"macd": macd_line, "signal": signal_line, "histogram": histogram}


def calc_bollinger(series: pd.Series, period: int = 20, std_dev: float = 2.0) -> dict:
    """Bollinger Bands."""
    sma = calc_sma(series, period)
    std = series.rolling(window=period).std()
    return {
        "middle": sma,
        "upper": sma + std_dev * std,
        "lower": sma - std_dev * std,
        "width": (2 * std_dev * std) / sma * 100,
    }


def calc_stochastic(high: pd.Series, low: pd.Series, close: pd.Series,
                     k_period: int = 14, d_period: int = 3) -> dict:
    """Stochastic Oscillator."""
    lowest_low = low.rolling(window=k_period).min()
    highest_high = high.rolling(window=k_period).max()
    k = 100 * (close - lowest_low) / (highest_high - lowest_low).replace(0, np.nan)
    d = k.rolling(window=d_period).mean()
    return {"k": k, "d": d}


def calc_atr(high: pd.Series, low: pd.Series, close: pd.Series,
             period: int = 14) -> pd.Series:
    """ATR — Average True Range."""
    tr1 = high - low
    tr2 = (high - close.shift(1)).abs()
    tr3 = (low - close.shift(1)).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    return tr.rolling(window=period).mean()


def calc_obv(close: pd.Series, volume: pd.Series) -> pd.Series:
    """OBV — On Balance Volume."""
    direction = np.sign(close.diff())
    return (volume * direction).cumsum()


def calc_vwap(high: pd.Series, low: pd.Series, close: pd.Series,
              volume: pd.Series) -> pd.Series:
    """VWAP — Volume Weighted Average Price (скользящий за 20 дней)."""
    typical_price = (high + low + close) / 3
    cum_tp_vol = (typical_price * volume).rolling(20).sum()
    cum_vol = volume.rolling(20).sum()
    return cum_tp_vol / cum_vol.replace(0, np.nan)


def detect_candle_patterns(df: pd.DataFrame) -> dict:
    """
    Детекция свечных паттернов на последних свечах.
    Возвращает dict с найденными паттернами.
    """
    if len(df) < 3:
        return {}

    patterns = {}
    o = df["open"].values
    h = df["high"].values
    l = df["low"].values
    c = df["close"].values
    body = c - o
    body_abs = np.abs(body)
    upper_shadow = h - np.maximum(o, c)
    lower_shadow = np.minimum(o, c) - l
    avg_body = pd.Series(body_abs).rolling(20).mean().values

    i = len(df) - 1
    candle_range = h[i] - l[i]

    # Доджи — тело < 10% от диапазона свечи
    if candle_range > 0 and body_abs[i] / candle_range < 0.1:
        patterns["Доджи"] = "Неопределённость, возможен разворот"

    # Молот (Hammer) — бычий разворот после падения
    if (lower_shadow[i] >= body_abs[i] * 2 and
            upper_shadow[i] < body_abs[i] * 0.5 and
            body[i-1] < 0 and body[i-2] < 0):
        patterns["Молот"] = "Бычий разворот (покупка)"

    # Повешенный (Hanging Man) — медвежий разворот после роста
    if (lower_shadow[i] >= body_abs[i] * 2 and
            upper_shadow[i] < body_abs[i] * 0.5 and
            body[i-1] > 0 and body[i-2] > 0):
        patterns["Повешенный"] = "Медвежий разворот (продажа)"

    # Бычье поглощение
    if (body[i-1] < 0 and body[i] > 0 and
            o[i] <= c[i-1] and c[i] >= o[i-1]):
        patterns["Бычье поглощение"] = "Сильный бычий сигнал"

    # Медвежье поглощение
    if (body[i-1] > 0 and body[i] < 0 and
            o[i] >= c[i-1] and c[i] <= o[i-1]):
        patterns["Медвежье поглощение"] = "Сильный медвежий сигнал"

    # Утренняя звезда (3 свечи)
    if len(df) >= 3:
        if (body[i-2] < 0 and
                body_abs[i-1] < body_abs[i-2] * 0.3 and
                body[i] > 0 and c[i] > (o[i-2] + c[i-2]) / 2):
            patterns["Утренняя звезда"] = "Бычий разворот (сильный)"

    # Вечерняя звезда
    if len(df) >= 3:
        if (body[i-2] > 0 and
                body_abs[i-1] < body_abs[i-2] * 0.3 and
                body[i] < 0 and c[i] < (o[i-2] + c[i-2]) / 2):
            patterns["Вечерняя звезда"] = "Медвежий разворот (сильный)"

    # Три белых солдата
    if (body[i] > 0 and body[i-1] > 0 and body[i-2] > 0 and
            c[i] > c[i-1] > c[i-2]):
        patterns["Три белых солдата"] = "Сильный бычий тренд"

    # Три чёрных вороны
    if (body[i] < 0 and body[i-1] < 0 and body[i-2] < 0 and
            c[i] < c[i-1] < c[i-2]):
        patterns["Три чёрных вороны"] = "Сильный медвежий тренд"

    # Бычий пин-бар
    if candle_range > 0:
        upper_ratio = upper_shadow[i] / candle_range
        lower_ratio = lower_shadow[i] / candle_range
        body_ratio = body_abs[i] / candle_range

        if lower_ratio > 0.6 and body_ratio < 0.25 and upper_ratio < 0.15:
            patterns["Бычий пин-бар"] = "Сильный разворот вверх (отскок от уровня)"

        if upper_ratio > 0.6 and body_ratio < 0.25 and lower_ratio < 0.15:
            patterns["Медвежий пин-бар"] = "Сильный разворот вниз (отбой от уровня)"

    # Марибозу
    if candle_range > 0 and i < len(avg_body) and not pd.isna(avg_body[i]):
        if body_abs[i] > avg_body[i] * 1.5:
            if (upper_shadow[i] < body_abs[i] * 0.05 and
                    lower_shadow[i] < body_abs[i] * 0.05):
                if body[i] > 0:
                    patterns["Бычья Марибозу"] = "Полный контроль покупателей"
                else:
                    patterns["Медвежья Марибозу"] = "Полный контроль продавцов"

    # Бычий Харами
    if i >= 1:
        if (body[i-1] < 0 and body[i] > 0 and
                body_abs[i] < body_abs[i-1] * 0.5 and
                c[i] < o[i-1] and o[i] > c[i-1]):
            patterns["Бычий Харами"] = "Ослабление медведей, возможен разворот"

        # Медвежий Харами
        if (body[i-1] > 0 and body[i] < 0 and
                body_abs[i] < body_abs[i-1] * 0.5 and
                o[i] < c[i-1] and c[i] > o[i-1]):
            patterns["Медвежий Харами"] = "Ослабление быков, возможен разворот"

    # Просвет в облаках (Piercing Line)
    if i >= 1:
        if (body[i-1] < 0 and body[i] > 0 and
                o[i] < l[i-1] and
                c[i] > (o[i-1] + c[i-1]) / 2 and c[i] < o[i-1]):
            patterns["Просвет в облаках"] = "Бычий разворот (покупатели перехватывают)"

    # Завеса тёмных облаков (Dark Cloud Cover)
    if i >= 1:
        if (body[i-1] > 0 and body[i] < 0 and
                o[i] > h[i-1] and
                c[i] < (o[i-1] + c[i-1]) / 2 and c[i] > o[i-1]):
            patterns["Завеса тёмных облаков"] = "Медвежий разворот (продавцы перехватывают)"

    return patterns


def detect_trendlines(df: pd.DataFrame, window: int = 60) -> dict:
    """
    Автоматическое определение линий тренда по локальным экстремумам.
    """
    recent = df.tail(window).copy().reset_index(drop=True)
    high = recent["high"].values
    low = recent["low"].values
    dates = recent["date"].values if "date" in recent.columns else recent.index.values

    local_mins = []
    for i in range(2, len(low) - 2):
        if (low[i] <= low[i-1] and low[i] <= low[i-2] and
                low[i] <= low[i+1] and low[i] <= low[i+2]):
            local_mins.append((i, low[i], dates[i]))

    local_maxs = []
    for i in range(2, len(high) - 2):
        if (high[i] >= high[i-1] and high[i] >= high[i-2] and
                high[i] >= high[i+1] and high[i] >= high[i+2]):
            local_maxs.append((i, high[i], dates[i]))

    result = {}

    if len(local_mins) >= 2:
        p1, p2 = local_mins[-2], local_mins[-1]
        if p2[1] > p1[1]:
            slope = (p2[1] - p1[1]) / (p2[0] - p1[0])
            end_val = p2[1] + slope * (len(recent) - 1 - p2[0])
            result["uptrend"] = {
                "start_date": p1[2], "start_val": float(p1[1]),
                "end_date": dates[-1], "end_val": float(end_val),
                "slope_pct": float(slope / p1[1] * 100),
            }

    if len(local_maxs) >= 2:
        p1, p2 = local_maxs[-2], local_maxs[-1]
        if p2[1] < p1[1]:
            slope = (p2[1] - p1[1]) / (p2[0] - p1[0])
            end_val = p2[1] + slope * (len(recent) - 1 - p2[0])
            result["downtrend"] = {
                "start_date": p1[2], "start_val": float(p1[1]),
                "end_date": dates[-1], "end_val": float(end_val),
                "slope_pct": float(slope / p1[1] * 100),
            }

    if "uptrend" in result and len(local_maxs) >= 2:
        p1, p2 = local_maxs[-2], local_maxs[-1]
        slope = (p2[1] - p1[1]) / max(p2[0] - p1[0], 1)
        end_val = p2[1] + slope * (len(recent) - 1 - p2[0])
        result["channel_upper"] = {
            "start_date": p1[2], "start_val": float(p1[1]),
            "end_date": dates[-1], "end_val": float(end_val),
        }

    if "downtrend" in result and len(local_mins) >= 2:
        p1, p2 = local_mins[-2], local_mins[-1]
        slope = (p2[1] - p1[1]) / max(p2[0] - p1[0], 1)
        end_val = p2[1] + slope * (len(recent) - 1 - p2[0])
        result["channel_lower"] = {
            "start_date": p1[2], "start_val": float(p1[1]),
            "end_date": dates[-1], "end_val": float(end_val),
        }

    if "uptrend" in result and "downtrend" in result:
        result["channel"] = "Сужающийся канал (треугольник)"
    elif "uptrend" in result:
        result["channel"] = "Восходящий тренд"
    elif "downtrend" in result:
        result["channel"] = "Нисходящий тренд"
    else:
        result["channel"] = "Боковик (нет чётких трендов)"

    return result


def detect_levels(df: pd.DataFrame, window: int = 60,
                  tolerance_pct: float = 1.0) -> dict:
    """
    Определение уровней поддержки и сопротивления
    методом кластеризации ценовых экстремумов.
    """
    recent = df.tail(window)
    high = recent["high"].values
    low = recent["low"].values
    close_last = float(recent["close"].iloc[-1])

    extremes = []
    for i in range(2, len(high) - 2):
        if high[i] >= high[i-1] and high[i] >= high[i+1]:
            extremes.append(high[i])
        if low[i] <= low[i-1] and low[i] <= low[i+1]:
            extremes.append(low[i])

    if not extremes:
        return {"support": [], "resistance": []}

    extremes.sort()
    tolerance = close_last * tolerance_pct / 100
    clusters = []
    current_cluster = [extremes[0]]

    for price in extremes[1:]:
        if price - current_cluster[-1] <= tolerance:
            current_cluster.append(price)
        else:
            clusters.append(current_cluster)
            current_cluster = [price]
    clusters.append(current_cluster)

    levels = []
    for cluster in clusters:
        if len(cluster) >= 2:
            levels.append({
                "price": round(sum(cluster) / len(cluster), 2),
                "touches": len(cluster),
                "strength": "сильный" if len(cluster) >= 4 else "умеренный",
            })

    support = [lv for lv in levels if lv["price"] < close_last]
    resistance = [lv for lv in levels if lv["price"] > close_last]

    support.sort(key=lambda x: close_last - x["price"])
    resistance.sort(key=lambda x: x["price"] - close_last)

    return {
        "support": support[:3],
        "resistance": resistance[:3],
    }


def detect_breakout(df: pd.DataFrame, levels: dict, price: float) -> list:
    """Определение пробоев уровней поддержки/сопротивления."""
    breakouts = []

    vol_ratio = 1.0
    if "volume" in df.columns:
        vol_mean = df["volume"].rolling(20).mean().iloc[-1]
        if vol_mean and vol_mean > 0:
            vol_ratio = df["volume"].iloc[-1] / vol_mean

    for res in levels.get("resistance", []):
        if price > res["price"]:
            confirmed = vol_ratio > 1.5
            breakouts.append({
                "type": "ПРОБОЙ СОПРОТИВЛЕНИЯ",
                "level": res["price"],
                "confirmed": confirmed,
                "description": (
                    f"Цена {price:.2f} пробила сопротивление {res['price']:.2f} "
                    f"({'на высоком объёме — подтверждён' if confirmed else 'на обычном объёме — требует подтверждения'})"
                ),
            })

    for sup in levels.get("support", []):
        if price < sup["price"]:
            confirmed = vol_ratio > 1.5
            breakouts.append({
                "type": "ПРОБОЙ ПОДДЕРЖКИ",
                "level": sup["price"],
                "confirmed": confirmed,
                "description": (
                    f"Цена {price:.2f} пробила поддержку {sup['price']:.2f} "
                    f"({'подтверждён объёмом' if confirmed else 'слабый — возможен ложный пробой'})"
                ),
            })

    return breakouts


def detect_divergence(close: pd.Series, rsi: pd.Series,
                      lookback: int = 20) -> list:
    """
    Определение дивергенций между ценой и RSI.
    """
    divergences = []
    if len(close) < lookback or len(rsi) < lookback:
        return divergences

    c_vals = close.values
    r_vals = rsi.values

    recent_c = c_vals[-lookback:]
    recent_r = r_vals[-lookback:]

    # Находим локальные минимумы цены
    price_mins = []
    for i in range(2, len(recent_c) - 1):
        if recent_c[i] <= recent_c[i-1] and recent_c[i] <= recent_c[i+1]:
            if not pd.isna(recent_r[i]):
                price_mins.append((i, recent_c[i], recent_r[i]))

    # Бычья дивергенция: цена — новый минимум, RSI — выше
    if len(price_mins) >= 2:
        prev, last = price_mins[-2], price_mins[-1]
        if last[1] < prev[1] and last[2] > prev[2]:
            divergences.append({
                "type": "Бычья дивергенция",
                "description": (
                    "Цена делает новый минимум, но RSI растёт. "
                    "Давление продавцов слабеет — возможен разворот вверх."
                ),
            })

    # Находим локальные максимумы цены
    price_maxs = []
    for i in range(2, len(recent_c) - 1):
        if recent_c[i] >= recent_c[i-1] and recent_c[i] >= recent_c[i+1]:
            if not pd.isna(recent_r[i]):
                price_maxs.append((i, recent_c[i], recent_r[i]))

    # Медвежья дивергенция: цена — новый максимум, RSI — ниже
    if len(price_maxs) >= 2:
        prev, last = price_maxs[-2], price_maxs[-1]
        if last[1] > prev[1] and last[2] < prev[2]:
            divergences.append({
                "type": "Медвежья дивергенция",
                "description": (
                    "Цена делает новый максимум, но RSI падает. "
                    "Импульс роста слабеет — возможен разворот вниз."
                ),
            })

    return divergences


def generate_signal(rsi: float, macd_hist: float, macd_hist_prev: float,
                    price: float, bb_upper: float, bb_lower: float,
                    sma_20: float, sma_50: float,
                    stoch_k: float, stoch_d: float) -> dict:
    """
    Генерация торгового сигнала на основе индикаторов.
    """
    bull_points = 0
    bear_points = 0
    reasons_bull = []
    reasons_bear = []

    if rsi < 30:
        bull_points += 2
        reasons_bull.append(f"RSI={rsi:.0f} — перепроданность")
    elif rsi < 40:
        bull_points += 1
        reasons_bull.append(f"RSI={rsi:.0f} — приближается к перепроданности")
    elif rsi > 70:
        bear_points += 2
        reasons_bear.append(f"RSI={rsi:.0f} — перекупленность")
    elif rsi > 60:
        bear_points += 1
        reasons_bear.append(f"RSI={rsi:.0f} — приближается к перекупленности")

    if macd_hist > 0 and macd_hist_prev <= 0:
        bull_points += 2
        reasons_bull.append("MACD — бычье пересечение")
    elif macd_hist > 0:
        bull_points += 1
        reasons_bull.append("MACD — положительная гистограмма")
    elif macd_hist < 0 and macd_hist_prev >= 0:
        bear_points += 2
        reasons_bear.append("MACD — медвежье пересечение")
    elif macd_hist < 0:
        bear_points += 1
        reasons_bear.append("MACD — отрицательная гистограмма")

    if price <= bb_lower:
        bull_points += 2
        reasons_bull.append("Цена на нижней Bollinger Band")
    elif price >= bb_upper:
        bear_points += 2
        reasons_bear.append("Цена на верхней Bollinger Band")

    if sma_20 > sma_50:
        bull_points += 1
        reasons_bull.append("SMA20 > SMA50 — бычий тренд")
    elif sma_20 < sma_50:
        bear_points += 1
        reasons_bear.append("SMA20 < SMA50 — медвежий тренд")

    if price > sma_20:
        bull_points += 1
        reasons_bull.append("Цена выше SMA20")
    else:
        bear_points += 1
        reasons_bear.append("Цена ниже SMA20")

    if stoch_k < 20 and stoch_d < 20:
        bull_points += 1
        reasons_bull.append(f"Stochastic K={stoch_k:.0f} — зона перепроданности")
    elif stoch_k > 80 and stoch_d > 80:
        bear_points += 1
        reasons_bear.append(f"Stochastic K={stoch_k:.0f} — зона перекупленности")

    diff = bull_points - bear_points
    if diff >= 3:
        signal = "ЛОНГ"
        strength = min(diff, 5)
        reasons = reasons_bull
    elif diff <= -3:
        signal = "ШОРТ"
        strength = min(abs(diff), 5)
        reasons = reasons_bear
    else:
        signal = "НЕЙТРАЛЬНО"
        strength = 0
        reasons = reasons_bull + reasons_bear

    return {
        "signal": signal,
        "strength": strength,
        "bull_points": bull_points,
        "bear_points": bear_points,
        "reasons": reasons,
    }


def full_analysis(df: pd.DataFrame) -> dict:
    """
    Полный технический анализ по свечам.
    df должен иметь колонки: open, high, low, close, volume (опционально).
    """
    if len(df) < 50:
        return {"error": "Недостаточно данных (нужно 50+ свечей)"}

    close = df["close"]
    high = df["high"]
    low = df["low"]

    rsi = calc_rsi(close, 14)
    macd_data = calc_macd(close)
    bb = calc_bollinger(close, 20)
    sma_20 = calc_sma(close, 20)
    sma_50 = calc_sma(close, 50)
    stoch = calc_stochastic(high, low, close)
    atr = calc_atr(high, low, close, 14)

    last = len(df) - 1
    prev = last - 1

    current = {
        "price": float(close.iloc[last]),
        "rsi": float(rsi.iloc[last]) if not pd.isna(rsi.iloc[last]) else 50,
        "macd": float(macd_data["macd"].iloc[last]) if not pd.isna(macd_data["macd"].iloc[last]) else 0,
        "macd_signal": float(macd_data["signal"].iloc[last]) if not pd.isna(macd_data["signal"].iloc[last]) else 0,
        "macd_hist": float(macd_data["histogram"].iloc[last]) if not pd.isna(macd_data["histogram"].iloc[last]) else 0,
        "macd_hist_prev": float(macd_data["histogram"].iloc[prev]) if not pd.isna(macd_data["histogram"].iloc[prev]) else 0,
        "bb_upper": float(bb["upper"].iloc[last]) if not pd.isna(bb["upper"].iloc[last]) else 0,
        "bb_lower": float(bb["lower"].iloc[last]) if not pd.isna(bb["lower"].iloc[last]) else 0,
        "bb_middle": float(bb["middle"].iloc[last]) if not pd.isna(bb["middle"].iloc[last]) else 0,
        "bb_width": float(bb["width"].iloc[last]) if not pd.isna(bb["width"].iloc[last]) else 0,
        "sma_20": float(sma_20.iloc[last]) if not pd.isna(sma_20.iloc[last]) else 0,
        "sma_50": float(sma_50.iloc[last]) if not pd.isna(sma_50.iloc[last]) else 0,
        "stoch_k": float(stoch["k"].iloc[last]) if not pd.isna(stoch["k"].iloc[last]) else 50,
        "stoch_d": float(stoch["d"].iloc[last]) if not pd.isna(stoch["d"].iloc[last]) else 50,
        "atr": float(atr.iloc[last]) if not pd.isna(atr.iloc[last]) else 0,
    }

    if current["sma_20"] > current["sma_50"] and current["price"] > current["sma_20"]:
        current["trend"] = "Восходящий"
    elif current["sma_20"] < current["sma_50"] and current["price"] < current["sma_20"]:
        current["trend"] = "Нисходящий"
    else:
        current["trend"] = "Боковой"

    # Уровни поддержки/сопротивления (кластерные)
    levels = detect_levels(df, window=60)
    if levels["support"]:
        current["support"] = levels["support"][0]["price"]
    else:
        recent = df.tail(60)
        current["support"] = float(recent["low"].rolling(20).min().iloc[-1])

    if levels["resistance"]:
        current["resistance"] = levels["resistance"][0]["price"]
    else:
        recent = df.tail(60)
        current["resistance"] = float(recent["high"].rolling(20).max().iloc[-1])

    current["levels"] = levels

    # Линии тренда
    current["trendlines"] = detect_trendlines(df, window=60)

    # Пробои
    current["breakouts"] = detect_breakout(df, levels, current["price"])

    # Дивергенции
    current["divergences"] = detect_divergence(close, rsi, lookback=20)

    # Доходность
    current["return_1d"] = float((close.iloc[-1] / close.iloc[-2] - 1) * 100) if len(close) > 1 else 0
    current["return_1w"] = float((close.iloc[-1] / close.iloc[-5] - 1) * 100) if len(close) > 5 else 0
    current["return_1m"] = float((close.iloc[-1] / close.iloc[-21] - 1) * 100) if len(close) > 21 else 0
    current["return_3m"] = float((close.iloc[-1] / close.iloc[-63] - 1) * 100) if len(close) > 63 else 0

    # Волатильность
    daily_returns = close.pct_change().dropna()
    current["volatility"] = float(daily_returns.std() * np.sqrt(252) * 100)

    # Паттерны свечей
    current["patterns"] = detect_candle_patterns(df.tail(5))

    # Сигнал
    signal = generate_signal(
        rsi=current["rsi"],
        macd_hist=current["macd_hist"],
        macd_hist_prev=current["macd_hist_prev"],
        price=current["price"],
        bb_upper=current["bb_upper"],
        bb_lower=current["bb_lower"],
        sma_20=current["sma_20"],
        sma_50=current["sma_50"],
        stoch_k=current["stoch_k"],
        stoch_d=current["stoch_d"],
    )
    current["signal"] = signal

    # Серии индикаторов для графиков
    current["series"] = {
        "rsi": rsi,
        "macd": macd_data,
        "bb": bb,
        "sma_20": sma_20,
        "sma_50": sma_50,
        "stoch": stoch,
        "atr": atr,
    }

    return current