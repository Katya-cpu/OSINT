import streamlit as st

st.set_page_config(
    page_title="Инвестиционный дашборд",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("Инвестиционный дашборд (Российский рынок)")
st.markdown("---")

st.markdown("### Разделы")

st.markdown("""
<table>
  <thead><tr><th>Страница</th><th>Описание</th></tr></thead>
  <tbody>
    <tr><td><strong>Рынок</strong></td><td>Индексы MOEX, котировки, хитмап секторов</td></tr>
    <tr><td><strong>Макро</strong></td><td>Ключевая ставка ЦБ, курсы валют, инфляция</td></tr>
    <tr><td><strong>Скринер</strong></td><td>Скринер акций + ML-кластеризация</td></tr>
    <tr><td><strong>Новости</strong></td><td>Российские деловые новости + AI-сентимент</td></tr>
    <tr><td><strong>Облигации</strong></td><td>ОФЗ, доходности, сравнение с депозитами</td></tr>
    <tr><td><strong>Портфель</strong></td><td>Анализ портфеля: доходность, риск, Sharpe</td></tr>
    <tr><td><strong>AI Советник</strong></td><td>Чат с AI-аналитиком по российскому рынку</td></tr>
  </tbody>
</table>
""", unsafe_allow_html=True)

st.markdown("👈 Выбери страницу в боковом меню.")

st.markdown("""
---
*Данные: MOEX ISS, ЦБ РФ, РБК, Коммерсант, ТАСС*  
*AI: Groq (LLaMA)*  
*⚠️ Не является инвестиционной рекомендацией*
""")