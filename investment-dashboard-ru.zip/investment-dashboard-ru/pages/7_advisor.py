import streamlit as st
from analysis.groq_advisor import free_question
from data.moex import get_index_current
from data.cbr import get_daily_rates, get_key_rate_history

st.set_page_config(page_title="AI Советник", layout="wide")
st.title("AI Инвестиционный советник")

st.markdown("""
Задай любой вопрос о российском фондовом рынке, инвестициях, стратегиях.

**Примеры:**
- Куда вложить 500 000 рублей на 3 года?
- Стоит ли сейчас покупать ОФЗ?
- Какие дивидендные акции на MOEX самые надёжные?
- ИИС тип А или тип Б — что выгоднее?
- Как защитить портфель от девальвации рубля?
""")

# Подгружаем актуальные данные один раз
@st.cache_data(ttl=600)
def get_market_context() -> str:
    """Собрать актуальный контекст для AI."""
    lines = []

    indices = get_index_current()
    if indices:
        for idx, d in indices.items():
            val = d.get("value")
            ch = d.get("change_%") or 0
            if val:
                lines.append(f"Индекс {idx}: {val:,.0f} ({ch:+.2f}%)")

    rates = get_daily_rates()
    if rates and rates.get("currencies"):
        for code in ["USD", "EUR", "CNY"]:
            if code in rates["currencies"]:
                c = rates["currencies"][code]
                lines.append(f"{code}/RUB: {c['value']:.2f} (изм: {c['change']:+.4f})")

    key_rate = get_key_rate_history()
    if not key_rate.empty:
        lines.append(f"Ключевая ставка ЦБ РФ: {key_rate['rate'].iloc[-1]}%")

    return "\n".join(lines) if lines else ""


market_context = get_market_context()

if market_context:
    with st.expander("Актуальные данные (передаются AI)"):
        st.text(market_context)

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

for msg in st.session_state.chat_history:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

user_input = st.chat_input("Задай вопрос...")

if user_input:
    st.session_state.chat_history.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    # Контекст = актуальные данные + история чата
    history = "\n".join(
        f"{m['role']}: {m['content']}"
        for m in st.session_state.chat_history[-6:]
    )
    full_context = f"АКТУАЛЬНЫЕ ДАННЫЕ НА СЕГОДНЯ:\n{market_context}\n\nИстория диалога:\n{history}"

    with st.chat_message("assistant"):
        with st.spinner("Думаю..."):
            response = free_question(user_input, full_context)
        st.markdown(response)

    st.session_state.chat_history.append({"role": "assistant", "content": response})

if st.button("Очистить историю"):
    st.session_state.chat_history = []
    st.rerun()