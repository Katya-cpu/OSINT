import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from data.moex import get_ofz_bonds
from data.cbr import get_key_rate_history
from analysis.groq_advisor import analyze_bonds
st.set_page_config(page_title="Облигации", layout="wide")
st.title("Облигации (ОФЗ)")

# --- ОФЗ ---
st.header("Государственные облигации (ОФЗ)")

with st.spinner("Загрузка ОФЗ..."):
    ofz = get_ofz_bonds()

if not ofz.empty:
    display_cols = {
        "SECID": "Тикер",
        "SHORTNAME": "Название",
        "LAST": "Цена (%)",
        "EFFECTIVEYIELD": "Доходность %",
        "COUPONVALUE": "Купон (руб)",
        "COUPONPERIOD": "Период купона",
        "NEXTCOUPON": "След. купон",
        "MATDATE": "Погашение",
        "DURATION": "Дюрация",
        "ACCRUEDINT": "НКД",
    }
    available = {k: v for k, v in display_cols.items() if k in ofz.columns}
    ofz_display = ofz[list(available.keys())].rename(columns=available)

    st.dataframe(ofz_display, use_container_width=True, hide_index=True)

    # График доходностей
    if "Доходность %" in ofz_display.columns and "Дюрация" in ofz_display.columns:
        ofz_chart = ofz_display.dropna(subset=["Доходность %", "Дюрация"])
        if not ofz_chart.empty:
            fig = px.scatter(ofz_chart, x="Дюрация", y="Доходность %",
                            hover_data=["Тикер", "Название", "Погашение"],
                            title="Кривая доходности ОФЗ",
                            size_max=10)
            fig.update_layout(height=500, xaxis_title="Дюрация (дней)",
                             yaxis_title="Эффективная доходность (%)")
            st.plotly_chart(fig, use_container_width=True)

    # Сравнение с ключевой ставкой
    st.subheader("Сравнение доходности ОФЗ с ключевой ставкой")
    key_rate = get_key_rate_history()
    if not key_rate.empty and "Доходность %" in ofz_display.columns:
        current_rate = key_rate["rate"].iloc[-1]
        avg_yield = ofz_display["Доходность %"].median()

        c1, c2, c3 = st.columns(3)
        c1.metric("Ключевая ставка", f"{current_rate}%")
        c2.metric("Медианная доходность ОФЗ", f"{avg_yield:.1f}%")
        c3.metric("Спред", f"{avg_yield - current_rate:+.1f}%")

        if avg_yield > current_rate:
            st.success("Доходность ОФЗ ВЫШЕ ключевой ставки — облигации привлекательны.")
        else:
            st.warning("Доходность ОФЗ НИЖЕ ключевой ставки — рынок ожидает снижения ставки.")

else:
    st.info("Нет данных по ОФЗ. Возможно, торги закрыты.")

# --- AI ---
st.header("AI-анализ облигаций")
if st.button("Запустить AI-анализ"):
    data_lines = []
    if not ofz.empty and "EFFECTIVEYIELD" in ofz.columns:
        yields = ofz["EFFECTIVEYIELD"].dropna()
        data_lines.append(f"Средняя доходность ОФЗ: {yields.mean():.1f}%")
        data_lines.append(f"Мин. доходность: {yields.min():.1f}%")
        data_lines.append(f"Макс. доходность: {yields.max():.1f}%")
    if not key_rate.empty:
        data_lines.append(f"Ключевая ставка ЦБ: {key_rate['rate'].iloc[-1]}%")

    with st.spinner("AI анализирует..."):
        result = analyze_bonds("\n".join(data_lines))
    st.markdown(result)