import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import numpy as np
from data.moex import get_candles
from analysis.indicators import full_analysis
from analysis.ml_engine import (
    compute_signal, detect_anomalies, detect_regime,
    score_attractiveness, market_model, monte_carlo_forecast,
    FEATURE_NAMES_RU
)
from config import MOEX_TICKERS, MOEX_SECTORS
st.set_page_config(page_title="Скринер акций", layout="wide")
st.title("Скринер акций MOEX + ML")
TICKERS = MOEX_TICKERS

tab1, tab2, tab3, tab4 = st.tabs([
    "Скринер", "Детальный анализ + Прогноз",
    "ML-модель", "Диагностика ML"
])


# ============================================================
# TAB 1: Скринер (правила, НЕ ML)
# ============================================================
with tab1:
    st.subheader("Скринер по техническим индикаторам")
    st.caption("Сигналы на основе правил (RSI, MACD, Bollinger, тренд). Это НЕ ML-модель.")

    if st.button("Обновить скринер", key="refresh_screener"):
        if "screener_results" in st.session_state:
            del st.session_state["screener_results"]

    if "screener_results" not in st.session_state:
        progress = st.progress(0)
        status = st.empty()
        total = len(TICKERS)
        results = []

        for i, ticker in enumerate(TICKERS):
            status.text(f"Анализ {ticker} ({i+1}/{total})")
            try:
                df = get_candles(ticker, days=365)
                if df is None or len(df) < 60:
                    continue
                analysis_data = full_analysis(df)
                if "error" in analysis_data:
                    continue
                sig = compute_signal(df)
                if "error" in sig:
                    continue
                anomaly = detect_anomalies(df)
                regime_data = detect_regime(df)
                attractiveness = score_attractiveness(
                    analysis_data, sig, anomaly, regime_data)

                anom_text = ""
                if anomaly.get("is_anomaly"):
                    anom_text = anomaly.get("explanation", "")

                results.append({
                    "Тикер": ticker,
                    "Сектор": MOEX_SECTORS.get(ticker, "—"),
                    "Цена": round(analysis_data["price"], 2),
                    "Изм.%": round(analysis_data.get("return_1d", 0), 2),
                    "RSI": round(analysis_data["rsi"], 1),
                    "MACD": round(analysis_data["macd_hist"], 4),
                    "Техн. сигнал": sig["signal"],
                    "Счёт": sig["net_score"],
                    "Быки%": sig["pct_bull"],
                    "Скоринг": attractiveness["score"],
                    "Привл.": attractiveness["category"],
                    "Режим": regime_data["regime"],
                    "Тренд": analysis_data.get("trendlines", {}).get("channel", "—"),
                    "Аномалия": anom_text,
                    "Паттерны": ", ".join(
                        analysis_data.get("patterns", {}).keys()) or "-",
                })
            except Exception:
                continue
            progress.progress((i + 1) / total)

        progress.empty()
        status.empty()
        st.session_state["screener_results"] = pd.DataFrame(results)

    screener_df = st.session_state["screener_results"]

    if screener_df.empty:
        st.warning("Нет данных. Возможно, торги закрыты.")
    else:
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            dir_filter = st.selectbox("Сигнал",
                ["Все", "СИЛЬНЫЙ ЛОНГ", "ЛОНГ", "НЕЙТРАЛЬНО",
                 "ШОРТ", "СИЛЬНЫЙ ШОРТ"])
        with col2:
            regime_filter = st.selectbox("Режим",
                ["Все"] + sorted(screener_df["Режим"].unique().tolist()))
        with col3:
            sector_filter = st.selectbox("Сектор",
                ["Все"] + sorted(screener_df["Сектор"].unique().tolist()))
        with col4:
            min_score = st.slider("Мин. скоринг", 0, 100, 0)

        filtered = screener_df.copy()
        if dir_filter != "Все":
            filtered = filtered[filtered["Техн. сигнал"] == dir_filter]
        if regime_filter != "Все":
            filtered = filtered[filtered["Режим"] == regime_filter]
        if sector_filter != "Все":
            filtered = filtered[filtered["Сектор"] == sector_filter]
        filtered = filtered[filtered["Скоринг"] >= min_score]
        filtered = filtered.sort_values("Скоринг", ascending=False)

        def color_signal(val):
            if val in ("СИЛЬНЫЙ ЛОНГ", "ЛОНГ"):
                return "background-color: #1b5e20; color: white"
            elif val in ("СИЛЬНЫЙ ШОРТ", "ШОРТ"):
                return "background-color: #b71c1c; color: white"
            return "background-color: #555555; color: white"

        def color_score(val):
            if isinstance(val, (int, float)):
                if val >= 70:
                    return "background-color: #1b5e20; color: white"
                elif val >= 40:
                    return "background-color: #e65100; color: white"
                return "background-color: #b71c1c; color: white"
            return ""

        styled = filtered.style.map(color_signal, subset=["Техн. сигнал"])
        styled = styled.map(color_score, subset=["Скоринг"])
        st.dataframe(styled, use_container_width=True, height=700)

        st.markdown("---")
        st.markdown(f"**Показано {len(filtered)} из {len(screener_df)} акций**")
        s1, s2, s3, s4 = st.columns(4)
        longs = len(screener_df[screener_df["Техн. сигнал"].isin(
            ["ЛОНГ", "СИЛЬНЫЙ ЛОНГ"])])
        shorts = len(screener_df[screener_df["Техн. сигнал"].isin(
            ["ШОРТ", "СИЛЬНЫЙ ШОРТ"])])
        neutrals = len(screener_df[screener_df["Техн. сигнал"] == "НЕЙТРАЛЬНО"])
        s1.metric("Лонг", longs)
        s2.metric("Шорт", shorts)
        s3.metric("Нейтрально", neutrals)
        s4.metric("Средний скоринг", f"{screener_df['Скоринг'].mean():.0f}")


# ============================================================
# TAB 2: Детальный анализ + Прогноз цены
# ============================================================
with tab2:
    st.subheader("Детальный технический анализ")

        # Инициализация сохранённого тикера
    if "saved_ticker" not in st.session_state:
        st.session_state.saved_ticker = TICKERS[0]
    def on_ticker_change():
        st.session_state.saved_ticker = st.session_state._detail_ticker_widget

    # Определяем индекс сохранённого тикера
    default_idx = 0
    if st.session_state.saved_ticker in TICKERS:
        default_idx = TICKERS.index(st.session_state.saved_ticker)

    selected = st.selectbox(
        "Выберите тикер",
        TICKERS,
        index=default_idx,
        key="_detail_ticker_widget",
        on_change=on_ticker_change
    )

    st.caption(f"Сектор: **{MOEX_SECTORS.get(selected, '—')}**")

    detail_col1, detail_col2 = st.columns(2)
    period = detail_col1.selectbox("Период",
        ["3 месяца", "6 месяцев", "1 год"], index=2, key="detail_period")
    chart_type = detail_col2.radio("Тип графика",
        ["Свечной", "Линейный", "Барный"], horizontal=True)
    period_days = {"3 месяца": 90, "6 месяцев": 180, "1 год": 365}[period]

    # --- Кэшированная загрузка технического анализа ---
    cache_key = f"detail_{selected}_{period_days}"
    if st.button("Обновить анализ", key="refresh_detail"):
        if cache_key in st.session_state:
            del st.session_state[cache_key]
        # Сбросить AI-кэш при смене тикера/обновлении
        for k in list(st.session_state.keys()):
            if k.startswith("ai_result_") or k.startswith("mc_result_"):
                del st.session_state[k]

    if cache_key not in st.session_state:
        with st.spinner(f"Загрузка {selected}..."):
            df = get_candles(selected, days=period_days)
            if df is None or len(df) < 50:
                st.session_state[cache_key] = (None,) * 6
            else:
                analysis_r = full_analysis(df)
                if "error" in analysis_r:
                    st.session_state[cache_key] = (None,) * 6
                else:
                    sig_r = compute_signal(df)
                    anomaly_r = detect_anomalies(df)
                    regime_r = detect_regime(df)
                    attract_r = score_attractiveness(
                        analysis_r, sig_r, anomaly_r, regime_r)
                    st.session_state[cache_key] = (
                        analysis_r, sig_r, anomaly_r,
                        regime_r, attract_r, df)

    analysis, sig, anomaly, regime, attractiveness, df = \
        st.session_state[cache_key]

    if analysis is None:
        st.warning("Нет данных для выбранного тикера.")
    else:
        signal_info = analysis["signal"]
        rsi_val = analysis["rsi"]

        # === МЕТРИКИ ===
        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric("Цена", f"{analysis['price']:.2f} руб",
                   f"{analysis['return_1d']:+.2f}%")
        c2.metric("RSI", f"{rsi_val:.1f}",
                   "Перекуплен" if rsi_val > 70 else (
                       "Перепродан" if rsi_val < 30 else "Норма"))
        c3.metric("Техн. сигнал", signal_info["signal"],
                   f"Сила: {signal_info['strength']}")
        c4.metric("Скоринг", f"{attractiveness['score']}/100",
                   attractiveness["category"])
        c5.metric("Режим", regime["regime"])

        # === ML-ПРОГНОЗ (кэшируется) ===
        ml_pred = None
        if market_model.is_trained:
            ml_cache_key = f"ml_pred_{selected}"
            if ml_cache_key not in st.session_state:
                st.session_state[ml_cache_key] = \
                    market_model.predict_ticker(selected)
            ml_pred = st.session_state[ml_cache_key]

            if ml_pred.get("error"):
                st.warning(f"ML: {ml_pred['error']}")
            m1, m2, m3 = st.columns(3)
            m1.metric("ML-прогноз", ml_pred.get("prediction", "—"))
            m2.metric("Вероятн. роста", f"{ml_pred.get('prob_up', 50)}%")
            m3.metric("Уверенность ML", ml_pred.get("confidence", "—"))

            # === ГЛУБОКИЙ AI-АНАЛИЗ (кэшируется) ===
            ai_cache_key = f"ai_result_{selected}"

            if st.button("Глубокий AI-анализ "
                         "(новости + интернет + геополитика)",
                         key="deep_ai"):
                # Сброс кэша для перезапуска
                if ai_cache_key in st.session_state:
                    del st.session_state[ai_cache_key]
                # Сброс Monte Carlo (т.к. AI может изменить bias)
                mc_key = f"mc_result_{selected}"
                if mc_key in st.session_state:
                    del st.session_state[mc_key]

                sector = MOEX_SECTORS.get(selected, "Другое")

                with st.spinner(
                    "Фаза 1/3: Сбор новостей из RSS "
                    "(50 записей/источник)..."
                ):
                    from data.news_ru import (
                        get_sector_news, get_deep_web_analysis,
                        format_web_data_for_ai
                    )
                    from analysis.groq_advisor import (
                        geopolitical_adjust_prediction,
                        analyze_stock_deep
                    )
                    news_data = get_sector_news(sector, ticker=selected)
                    total_found = sum(len(v) for v in news_data.values())

                with st.spinner(
                    "Фаза 2/3: Парсинг Smart-Lab, БКС, Investing.com, "
                    "Тинькофф, dohod.ru + геополитический контекст..."
                ):
                    web_data = get_deep_web_analysis(selected, sector)
                    web_text = format_web_data_for_ai(web_data)

                with st.spinner("Фаза 3/3: AI анализирует все данные..."):
                    adjustment = geopolitical_adjust_prediction(
                        ticker=selected,
                        sector=sector,
                        ml_prob_up=ml_pred.get("prob_up", 50),
                        ml_prediction=ml_pred.get("prediction",
                                                   "Неопределённо"),
                        news_by_category=news_data,
                        web_data_text=web_text,
                    )

                    tech_summary = (
                        f"Цена: {analysis['price']:.2f}, "
                        f"RSI: {rsi_val:.1f}, "
                        f"MACD hist: {analysis['macd_hist']:.4f}, "
                        f"Тренд: {analysis.get('trend', 'Боковой')}, "
                        f"Bollinger: {analysis['bb_width']:.1f}%, "
                        f"Stoch K/D: {analysis['stoch_k']:.0f}/"
                        f"{analysis['stoch_d']:.0f}, "
                        f"1д: {analysis['return_1d']:+.2f}%, "
                        f"1нед: {analysis['return_1w']:+.2f}%, "
                        f"1мес: {analysis['return_1m']:+.2f}%, "
                        f"Волат: {analysis['volatility']:.1f}%, "
                        f"Скоринг: {attractiveness['score']}/100, "
                        f"Режим: {regime['regime']}"
                    )

                    deep_analysis = analyze_stock_deep(
                        ticker=selected, sector=sector,
                        technical_data=tech_summary,
                        ml_prediction=ml_pred,
                        news_by_category=news_data,
                        web_data_text=web_text,
                    )

                # Сохраняем в кэш
                st.session_state[ai_cache_key] = {
                    "adjustment": adjustment,
                    "deep_analysis": deep_analysis,
                    "news_data": news_data,
                    "web_data": web_data,
                    "total_found": total_found,
                }

            # Отображение AI-результатов (из кэша)
            if ai_cache_key in st.session_state:
                ai = st.session_state[ai_cache_key]
                adjustment = ai["adjustment"]
                deep_analysis = ai["deep_analysis"]
                news_data = ai["news_data"]
                web_data = ai["web_data"]
                total_found = ai["total_found"]

                verdict = adjustment["verdict"]
                nc = adjustment["news_counts"]

                st.markdown("---")
                st.markdown("### Результаты глубокого AI-анализа")

                sources_found = []
                if web_data.get("smart_lab", {}).get("fundamentals"):
                    sources_found.append("Smart-Lab")
                if web_data.get("investing_com"):
                    sources_found.append("Investing.com")
                if web_data.get("bcs"):
                    sources_found.append("БКС")
                if web_data.get("tinkoff"):
                    sources_found.append("Тинькофф")
                if web_data.get("dohod_dividends"):
                    sources_found.append("dohod.ru")
                if web_data.get("geo_context"):
                    sources_found.append("Геоконтекст")

                st.markdown(
                    f"**Источники:** RSS ({total_found} новостей) + "
                    f"Web ({', '.join(sources_found) or 'нет'})")
                st.markdown(
                    f"**Новости:** компания: {nc['company']}, "
                    f"отрасль: {nc['sector']}, "
                    f"геополитика: {nc['geopolitics']}, "
                    f"макро: {nc['macro']}")

                if "ПОЗИТИВНО" in verdict:
                    st.success(
                        f"**Вердикт: {verdict}** | "
                        f"ML: {ml_pred.get('prob_up', 50)}% → "
                        f"**{adjustment['adjusted_prob']}%** "
                        f"({adjustment['prob_delta']:+.0f}%)")
                elif "НЕГАТИВНО" in verdict:
                    st.error(
                        f"**Вердикт: {verdict}** | "
                        f"ML: {ml_pred.get('prob_up', 50)}% → "
                        f"**{adjustment['adjusted_prob']}%** "
                        f"({adjustment['prob_delta']:+.0f}%)")
                else:
                    st.info(
                        f"**Вердикт: {verdict}** | "
                        f"Вероятность: "
                        f"**{adjustment['adjusted_prob']}%**")

                adj1, adj2 = st.columns(2)
                adj1.metric("ML (исходный)",
                    ml_pred.get("prediction", "—"),
                    f"{ml_pred.get('prob_up', 50)}%")
                adj2.metric("AI-скорректированный",
                    adjustment["adjusted_prediction"],
                    f"{adjustment['adjusted_prob']}% "
                    f"({adjustment['prob_delta']:+.0f}%)")

                st.markdown("---")
                st.markdown("### Комплексный AI-анализ")
                st.markdown(deep_analysis)

                with st.expander("Геополитический анализ (детали)"):
                    st.markdown(adjustment["explanation"])

                with st.expander(f"Все новости ({total_found})"):
                    for cat, label in [
                        ("company", "О компании"),
                        ("sector", "Отрасль"),
                        ("geopolitics", "Геополитика"),
                        ("macro", "Макроэкономика"),
                    ]:
                        items = news_data.get(cat, [])
                        if items:
                            st.markdown(f"**{label}:**")
                            for n in items:
                                st.markdown(
                                    f"- [{n.get('source', '')}] "
                                    f"{n['title']}")

                with st.expander("Данные из интернета (сырые)"):
                    sl = web_data.get("smart_lab", {})
                    if sl.get("fundamentals"):
                        st.markdown("**Smart-Lab: фундаментал**")
                        st.text(sl["fundamentals"])
                    if sl.get("discussions"):
                        st.markdown("**Smart-Lab: обсуждения**")
                        for d in sl["discussions"]:
                            st.markdown(f"- {d}")
                    if web_data.get("investing_com"):
                        st.markdown("**Investing.com**")
                        st.text(web_data["investing_com"][:500])
                    if web_data.get("bcs"):
                        st.markdown("**БКС**")
                        st.text(web_data["bcs"][:500])
                    if web_data.get("dohod_dividends"):
                        st.markdown("**dohod.ru: дивиденды**")
                        st.text(web_data["dohod_dividends"][:500])
                    if web_data.get("geo_context"):
                        st.markdown("**Геополитический контекст**")
                        st.text(web_data["geo_context"][:800])

        # Аномалия
        if anomaly.get("is_anomaly"):
            reasons_text = "; ".join(anomaly.get("reasons", []))
            st.warning(f"Аномалия: {reasons_text}")

        # Пробои
        for bo in analysis.get("breakouts", []):
            if bo["confirmed"]:
                st.error(f"**{bo['type']}**: {bo['description']}")
            else:
                st.warning(f"**{bo['type']}**: {bo['description']}")

        # Дивергенции
        for div in analysis.get("divergences", []):
            if "Бычья" in div["type"]:
                st.success(f"**{div['type']}**: {div['description']}")
            else:
                st.warning(f"**{div['type']}**: {div['description']}")

        # === ОСНОВНОЙ ГРАФИК ===
        series = analysis["series"]
        dates = df["date"] if "date" in df.columns else df.index

        fig = make_subplots(
            rows=4, cols=1, shared_xaxes=True,
            vertical_spacing=0.04,
            row_heights=[0.5, 0.15, 0.15, 0.2],
            subplot_titles=["Цена + индикаторы", "RSI (14)",
                            "Stochastic", "MACD"])

        if chart_type == "Свечной":
            fig.add_trace(go.Candlestick(
                x=dates, open=df["open"], high=df["high"],
                low=df["low"], close=df["close"], name="Цена"
            ), row=1, col=1)
        elif chart_type == "Линейный":
            fig.add_trace(go.Scatter(
                x=dates, y=df["close"], name="Цена",
                line=dict(color="#1f77b4", width=2)
            ), row=1, col=1)
        elif chart_type == "Барный":
            fig.add_trace(go.Ohlc(
                x=dates, open=df["open"], high=df["high"],
                low=df["low"], close=df["close"], name="Цена"
            ), row=1, col=1)

        fig.add_trace(go.Scatter(
            x=dates, y=series["bb"]["upper"], name="BB верх",
            line=dict(color="rgba(100,100,255,0.3)")
        ), row=1, col=1)
        fig.add_trace(go.Scatter(
            x=dates, y=series["bb"]["lower"], name="BB низ",
            line=dict(color="rgba(100,100,255,0.3)"),
            fill="tonexty", fillcolor="rgba(100,100,255,0.05)"
        ), row=1, col=1)
        fig.add_trace(go.Scatter(
            x=dates, y=series["sma_20"], name="SMA 20",
            line=dict(color="orange", width=1)
        ), row=1, col=1)
        fig.add_trace(go.Scatter(
            x=dates, y=series["sma_50"], name="SMA 50",
            line=dict(color="cyan", width=1)
        ), row=1, col=1)

        levels = analysis.get("levels", {})
        for sup in levels.get("support", []):
            fig.add_hline(y=sup["price"], line_dash="dot",
                line_color="green",
                annotation_text=f"Подд. {sup['price']} ({sup['touches']})",
                row=1, col=1)
        for res in levels.get("resistance", []):
            fig.add_hline(y=res["price"], line_dash="dot",
                line_color="red",
                annotation_text=f"Сопр. {res['price']} ({res['touches']})",
                row=1, col=1)

        trendlines = analysis.get("trendlines", {})
        for tl_key, tl_name, tl_color in [
            ("uptrend", "Восх. тренд", "lime"),
            ("downtrend", "Нисх. тренд", "red"),
        ]:
            if tl_key in trendlines:
                t = trendlines[tl_key]
                fig.add_trace(go.Scatter(
                    x=[t["start_date"], t["end_date"]],
                    y=[t["start_val"], t["end_val"]],
                    mode="lines", name=tl_name,
                    line=dict(color=tl_color, width=2, dash="dash")
                ), row=1, col=1)
        for ch_key, ch_name in [
            ("channel_upper", "Верх канала"),
            ("channel_lower", "Низ канала"),
        ]:
            if ch_key in trendlines:
                t = trendlines[ch_key]
                fig.add_trace(go.Scatter(
                    x=[t["start_date"], t["end_date"]],
                    y=[t["start_val"], t["end_val"]],
                    mode="lines", name=ch_name,
                    line=dict(color="rgba(255,255,0,0.4)",
                              width=1, dash="dot")
                ), row=1, col=1)

        fig.add_trace(go.Scatter(
            x=dates, y=series["rsi"], name="RSI",
            line=dict(color="purple")), row=2, col=1)
        fig.add_hline(y=70, line_dash="dash", line_color="red",
                      row=2, col=1)
        fig.add_hline(y=30, line_dash="dash", line_color="green",
                      row=2, col=1)
        fig.add_hline(y=50, line_dash="dot", line_color="gray",
                      row=2, col=1)

        fig.add_trace(go.Scatter(
            x=dates, y=series["stoch"]["k"], name="Stoch %K",
            line=dict(color="#4fc3f7", width=1.5)), row=3, col=1)
        fig.add_trace(go.Scatter(
            x=dates, y=series["stoch"]["d"], name="Stoch %D",
            line=dict(color="#ff7043", width=1.5)), row=3, col=1)
        fig.add_hline(y=80, line_dash="dash", line_color="red",
                      row=3, col=1)
        fig.add_hline(y=20, line_dash="dash", line_color="green",
                      row=3, col=1)

        fig.add_trace(go.Scatter(
            x=dates, y=series["macd"]["macd"], name="MACD",
            line=dict(color="blue")), row=4, col=1)
        fig.add_trace(go.Scatter(
            x=dates, y=series["macd"]["signal"], name="Signal",
            line=dict(color="red")), row=4, col=1)
        macd_colors = ["green" if v >= 0 else "red"
                       for v in series["macd"]["histogram"]]
        fig.add_trace(go.Bar(
            x=dates, y=series["macd"]["histogram"], name="Гист.",
            marker_color=macd_colors), row=4, col=1)

        fig.update_layout(
            height=1000, template="plotly_dark",
            xaxis_rangeslider_visible=False, showlegend=True,
            legend=dict(orientation="h", yanchor="bottom",
                        y=1.02, x=0))
        st.plotly_chart(fig, use_container_width=True)

        # === ИНТЕРПРЕТАЦИЯ ОСЦИЛЛЯТОРОВ ===
        st.markdown("---")
        st.markdown("### Интерпретация индикаторов")
        osc_col1, osc_col2 = st.columns(2)

        with osc_col1:
            st.markdown("#### RSI")
            if rsi_val > 70:
                st.error(f"RSI = {rsi_val:.1f} — **Перекупленность**")
                st.markdown("Актив перегрет. **Действие:** фиксация прибыли.")
            elif rsi_val > 60:
                st.warning(f"RSI = {rsi_val:.1f} — **Приближение к перекупл.**")
            elif rsi_val < 30:
                st.success(f"RSI = {rsi_val:.1f} — **Перепроданность**")
                st.markdown("**Действие:** искать вход при развороте.")
            elif rsi_val < 40:
                st.info(f"RSI = {rsi_val:.1f} — **Приближение к перепрод.**")
            else:
                st.markdown(f"RSI = {rsi_val:.1f} — **Нейтрально**.")

            for div in analysis.get("divergences", []):
                if "Бычья" in div["type"]:
                    st.success(f"**{div['type']}**: {div['description']}")
                else:
                    st.warning(f"**{div['type']}**: {div['description']}")

            st.markdown("#### Стохастик")
            stoch_k = analysis["stoch_k"]
            stoch_d = analysis["stoch_d"]
            if stoch_k < 20 and stoch_d < 20:
                st.success(f"K={stoch_k:.0f}, D={stoch_d:.0f} — **Перепрод.**")
            elif stoch_k > 80 and stoch_d > 80:
                st.error(f"K={stoch_k:.0f}, D={stoch_d:.0f} — **Перекупл.**")
            else:
                cross = "бычье" if stoch_k > stoch_d else "медвежье"
                st.markdown(f"K={stoch_k:.0f}, D={stoch_d:.0f} — {cross}.")

        with osc_col2:
            st.markdown("#### MACD")
            macd_hist_val = analysis["macd_hist"]
            macd_val = analysis["macd"]
            macd_sig_val = analysis["macd_signal"]
            if macd_val > macd_sig_val and macd_hist_val > 0:
                st.success(f"MACD бычий, гист. +{macd_hist_val:.4f}")
            elif macd_val < macd_sig_val and macd_hist_val < 0:
                st.error(f"MACD медвежий, гист. {macd_hist_val:.4f}")
            else:
                st.info("MACD в переходной зоне.")

            st.markdown("#### Bollinger Bands")
            bb_width = analysis["bb_width"]
            if analysis["price"] >= analysis["bb_upper"]:
                st.error(f"Цена на **верхней** границе. Ширина: {bb_width:.1f}%.")
            elif analysis["price"] <= analysis["bb_lower"]:
                st.success(f"Цена на **нижней** границе. Ширина: {bb_width:.1f}%.")
            else:
                st.markdown(f"Цена внутри канала. Ширина: {bb_width:.1f}%.")
            if bb_width < 5:
                st.warning("**Сжатие Bollinger** — предвестник движения.")

            st.markdown("#### Тренд")
            trend = analysis.get("trend", "Боковой")
            tl_info = analysis.get("trendlines", {})
            channel_type = tl_info.get("channel", "—")
            if trend == "Восходящий":
                st.success(f"**{trend}**. Канал: {channel_type}.")
            elif trend == "Нисходящий":
                st.error(f"**{trend}**. Канал: {channel_type}.")
            else:
                st.info(f"**{trend}**. Канал: {channel_type}.")

        # === ГОЛОСОВАНИЕ ===
        st.markdown("---")
        st.markdown("### Голосование индикаторов")
        vote_a, vote_b = st.columns(2)
        with vote_a:
            for name, vote, reason in sig.get("votes", []):
                emoji = "🟢" if vote > 0 else ("🔴" if vote < 0 else "⚪")
                st.markdown(f"{emoji} **{name}** ({vote:+d}): {reason}")
            st.markdown(f"**Итог:** {sig['signal']} ({sig['net_score']:+d})")

        with vote_b:
            st.markdown("**Свечные паттерны:**")
            patterns = analysis.get("patterns", {})
            if patterns:
                for p_name, p_desc in patterns.items():
                    if any(w in p_desc.lower()
                           for w in ["бычий", "покупк", "рост"]):
                        st.markdown(f"🟢 **{p_name}** — {p_desc}")
                    elif any(w in p_desc.lower()
                             for w in ["медвежий", "продаж", "падение"]):
                        st.markdown(f"🔴 **{p_name}** — {p_desc}")
                    else:
                        st.markdown(f"⚪ **{p_name}** — {p_desc}")
            else:
                st.markdown("Нет активных паттернов")

            st.markdown("**Ключевые уровни:**")
            for sup in levels.get("support", []):
                st.markdown(f"🟢 Поддержка **{sup['price']:.2f}** "
                            f"({sup['touches']} кас.)")
            for res in levels.get("resistance", []):
                st.markdown(f"🔴 Сопротивл. **{res['price']:.2f}** "
                            f"({res['touches']} кас.)")

        # === ДОХОДНОСТИ ===
        st.markdown("### Доходность")
        r1, r2, r3, r4, r5 = st.columns(5)
        r1.metric("1 день", f"{analysis['return_1d']:+.2f}%")
        r2.metric("1 неделя", f"{analysis['return_1w']:+.2f}%")
        r3.metric("1 месяц", f"{analysis['return_1m']:+.2f}%")
        r4.metric("3 месяца", f"{analysis['return_3m']:+.2f}%")
        r5.metric("Волатильность", f"{analysis['volatility']:.1f}%")

        # === ИТОГОВЫЙ ВЕРДИКТ ===
        st.markdown("---")
        st.markdown("## Итоговый анализ")

        st.divider()
        st.caption(
            "⚠️ **Дисклеймер**: Блок «Итоговый анализ» ниже основан **исключительно на техническом анализе** "
            "(индикаторы RSI, MACD, Bollinger Bands, Stochastic, SMA/EMA и др.) и **НЕ учитывает** "
            "результаты ML-прогноза, AI-анализа новостей/геополитики и Monte Carlo симуляций. "
            "Поэтому его выводы могут отличаться от вердиктов ML, AI и Monte Carlo — это нормально, "
            "так как каждый метод анализирует разные аспекты рынка."
        )

        vp = []
        vb = 0
        vbr = 0

        if rsi_val < 30:
            vb += 2; vp.append(("bull", "RSI перепроданность"))
        elif rsi_val > 70:
            vbr += 2; vp.append(("bear", "RSI перекупленность"))
        if macd_hist_val > 0:
            vb += 1; vp.append(("bull", "MACD бычий"))
        else:
            vbr += 1; vp.append(("bear", "MACD медвежий"))
        if trend == "Восходящий":
            vb += 2; vp.append(("bull", "Восходящий тренд"))
        elif trend == "Нисходящий":
            vbr += 2; vp.append(("bear", "Нисходящий тренд"))
        else:
            vp.append(("neutral", "Боковой тренд"))
        if analysis["price"] <= analysis["bb_lower"]:
            vb += 1; vp.append(("bull", "Цена у нижней Bollinger"))
        elif analysis["price"] >= analysis["bb_upper"]:
            vbr += 1; vp.append(("bear", "Цена у верхней Bollinger"))
        if stoch_k < 20:
            vb += 1; vp.append(("bull", "Stochastic перепродан"))
        elif stoch_k > 80:
            vbr += 1; vp.append(("bear", "Stochastic перекуплен"))
        for p_name, p_desc in patterns.items():
            if any(w in p_desc.lower()
                   for w in ["бычий", "покупк", "рост"]):
                vb += 1; vp.append(("bull", f"Паттерн \"{p_name}\""))
            elif any(w in p_desc.lower()
                     for w in ["медвежий", "продаж", "падение"]):
                vbr += 1; vp.append(("bear", f"Паттерн \"{p_name}\""))
        for div in analysis.get("divergences", []):
            if "Бычья" in div["type"]:
                vb += 2; vp.append(("bull", div["type"]))
            else:
                vbr += 2; vp.append(("bear", div["type"]))
        for bo in analysis.get("breakouts", []):
            if "СОПРОТИВЛЕНИЯ" in bo["type"]:
                vb += 2 if bo["confirmed"] else 1
                vp.append(("bull", bo["description"]))
            elif "ПОДДЕРЖКИ" in bo["type"]:
                vbr += 2 if bo["confirmed"] else 1
                vp.append(("bear", bo["description"]))

        for vtype, vtext in vp:
            emoji = "🟢" if vtype == "bull" else (
                "🔴" if vtype == "bear" else "⚪")
            st.markdown(f"{emoji} {vtext}")

        total_v = max(vb + vbr, 1)
        pct_bull = vb / total_v * 100

        st.markdown("---")
        if pct_bull >= 70:
            st.success(
                f"### ПОКУПКА ({pct_bull:.0f}% бычьих)\n\n"
                f"Стоп-лосс **{analysis['support']:.2f}**, "
                f"цель **{analysis['resistance']:.2f}**.")
        elif pct_bull >= 55:
            st.info(f"### УМЕРЕННАЯ ПОКУПКА ({pct_bull:.0f}% бычьих)")
        elif pct_bull >= 45:
            st.warning(f"### НЕЙТРАЛЬНО ({pct_bull:.0f}% бычьих)")
        elif pct_bull >= 30:
            st.warning(f"### УМЕРЕННАЯ ПРОДАЖА ({pct_bull:.0f}% бычьих)")
        else:
            st.error(f"### ПРОДАЖА ({pct_bull:.0f}% бычьих)")

        st.caption("Не является инвестиционной рекомендацией.")

        # ======= MONTE CARLO (с AI-корректировкой) =======
        st.markdown("---")
        st.markdown("### Прогноз цены (Monte Carlo)")
        st.caption(
            "ML-прогноз корректирует drift. Если AI-анализ выполнен, "
            "его вердикт ДОПОЛНИТЕЛЬНО уточняет прогноз.")

        fc1, fc2 = st.columns(2)
        forecast_days = fc1.selectbox("Горизонт", [5, 10, 20],
            index=0, key="mc_days",
            format_func=lambda x: f"{x} дней")
        n_sims = fc2.selectbox("Симуляций", [500, 1000, 2000],
            index=1, key="mc_sims")

        mc_cache_key = f"mc_result_{selected}"

        if st.button("Построить прогноз", key="mc_run"):
            if mc_cache_key in st.session_state:
                del st.session_state[mc_cache_key]

            # Шаг 1: базовый ML-bias
            ml_bias = 0.0
            bias_source = "без ML"
            if market_model.is_trained and ml_pred and "error" not in ml_pred:
                ml_prob = ml_pred["prob_up"]
                ml_bias = (ml_prob / 100 - 0.5) * 0.002
                bias_source = f"ML prob={ml_prob}%"

            # Шаг 2: AI-корректировка поверх ML
            ai_cache = f"ai_result_{selected}"
            if ai_cache in st.session_state:
                adj = st.session_state[ai_cache]["adjustment"]
                ai_prob = adj["adjusted_prob"]
                # Пересчитываем bias с AI-скорректированной вероятностью
                ml_bias = (ai_prob / 100 - 0.5) * 0.002
                bias_source = (
                    f"ML {ml_pred.get('prob_up', 50)}% → "
                    f"AI {ai_prob}% (вердикт: {adj['verdict']})")

            forecast = monte_carlo_forecast(
                df["close"], days_ahead=forecast_days,
                n_sims=n_sims, ml_bias=ml_bias)

            st.session_state[mc_cache_key] = {
                "forecast": forecast,
                "bias_source": bias_source,
                "forecast_days": forecast_days,
                "n_sims": n_sims,
            }

        # Отображение Monte Carlo (из кэша)
        if mc_cache_key in st.session_state:
            mc = st.session_state[mc_cache_key]
            forecast = mc["forecast"]
            bias_source = mc["bias_source"]

            st.info(f"**Drift-корректировка:** {bias_source}")

            last_date = pd.to_datetime(df["date"].iloc[-1])
            future_dates = pd.bdate_range(
                start=last_date,
                periods=mc["forecast_days"] + 1)

            # --- Monte Carlo chart ---
            fig_mc = go.Figure()
            # Извлекаем данные из forecast
            hist_prices = df["close"].tolist()  # история из загруженного df
            paths = forecast["paths"]            # массив симуляций из monte_carlo_forecast

            # История цен — тёмно-синяя линия
            fig_mc.add_trace(go.Scatter(
                x=list(range(len(hist_prices))),
                y=hist_prices,
                mode="lines",
                name="История цены",
                line=dict(color="#1f3864", width=2.5)
            ))

            # Симуляции (первые 50)
            for i, path in enumerate(paths[:50]):
                full_path = [hist_prices[-1]] + list(path)
                x_sim = list(range(len(hist_prices) - 1,
                                   len(hist_prices) - 1 + len(full_path)))
                fig_mc.add_trace(go.Scatter(
                    x=x_sim, y=full_path,
                    mode="lines",
                    line=dict(width=0.5, color="rgba(100,100,255,0.15)"),
                    showlegend=(i == 0),
                    name="Симуляции" if i == 0 else None
                ))

            # Медиана
            median_path = np.median(paths, axis=0)
            full_median = [hist_prices[-1]] + list(median_path)
            x_median = list(range(len(hist_prices) - 1,
                                  len(hist_prices) - 1 + len(full_median)))
            fig_mc.add_trace(go.Scatter(
                x=x_median, y=full_median,
                mode="lines",
                name="Медиана прогноза",
                line=dict(color="#e74c3c", width=2.5, dash="dash")
            ))

            # Перцентили 10/90
            p10 = np.percentile(paths, 10, axis=0)
            p90 = np.percentile(paths, 90, axis=0)
            full_p10 = [hist_prices[-1]] + list(p10)
            full_p90 = [hist_prices[-1]] + list(p90)

            fig_mc.add_trace(go.Scatter(
                x=x_median, y=full_p90,
                mode="lines",
                name="90-й перцентиль",
                line=dict(color="rgba(46,204,113,0.6)", width=1, dash="dot")
            ))
            fig_mc.add_trace(go.Scatter(
                x=x_median, y=full_p10,
                mode="lines",
                name="10-й перцентиль",
                line=dict(color="rgba(231,76,60,0.6)", width=1, dash="dot"),
                fill="tonexty",
                fillcolor="rgba(200,200,255,0.1)"
            ))

            fig_mc.update_layout(
                title=f"Прогноз цены (Monte Carlo, {mc['forecast_days']} дней, {mc['n_sims']} симуляций)",
                xaxis_title="Торговые дни",
                yaxis_title="Цена, ₽",
                template="plotly_white",
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=1.02,
                    xanchor="right",
                    x=1
                ),
                height=500
            )
            st.plotly_chart(fig_mc, use_container_width=True)

            pm1, pm2, pm3, pm4 = st.columns(4)
            pm1.metric("Текущая", f"{forecast['last_price']:.2f}")
            pm2.metric("Медиана", f"{forecast['p50'][-1]:.2f}",
                f"{(forecast['p50'][-1]/forecast['last_price']-1)*100:+.1f}%")
            pm3.metric("Вер. роста",
                f"{forecast['prob_above_current']}%")
            pm4.metric("90% диапазон",
                f"{forecast['p5'][-1]:.2f} — {forecast['p95'][-1]:.2f}")


# ============================================================
# TAB 3: ML-модель
# ============================================================
with tab3:
    st.subheader("ML-модель рынка (GradientBoosting)")
    st.markdown(f"Модель обучается на **{len(TICKERS)} акциях** за 3 года.")
    st.markdown("### Настройка гиперпараметров")

    hp1, hp2, hp3 = st.columns(3)
    with hp1:
        hp_n_est = st.slider("Деревья", 100, 1000,
            market_model.params.get("n_estimators", 500), step=50)
        hp_depth = st.slider("Глубина", 2, 8,
            market_model.params.get("max_depth", 4))
    with hp2:
        hp_lr = st.select_slider("Шаг обучения",
            options=[0.01, 0.02, 0.03, 0.05, 0.08, 0.1, 0.15],
            value=market_model.params.get("learning_rate", 0.03))
        hp_leaf = st.slider("Мин. в листе", 10, 100,
            market_model.params.get("min_samples_leaf", 50), step=5)
    with hp3:
        hp_sub = st.select_slider("Subsample",
            options=[0.6, 0.7, 0.8, 0.9, 1.0],
            value=market_model.params.get("subsample", 0.8))
        hp_thr = st.select_slider("Порог шума",
            options=[0.0, 0.002, 0.003, 0.005, 0.008, 0.01, 0.015],
            value=market_model.params.get("target_threshold", 0.005),
            format_func=lambda x: f"+-{x*100:.1f}%")

    custom_params = {
        "n_estimators": hp_n_est, "max_depth": hp_depth,
        "learning_rate": hp_lr, "min_samples_leaf": hp_leaf,
        "subsample": hp_sub, "max_features": 0.6,
        "target_threshold": hp_thr,
    }

    if st.button("Обучить модель", key="train_model"):
        progress_bar = st.progress(0)
        status_txt = st.empty()

        def update_progress(pct, text):
            progress_bar.progress(min(pct, 1.0))
            status_txt.text(text)

        try:
            metrics = market_model.train(
                progress_callback=update_progress,
                params=custom_params)
            if "error" in metrics:
                st.error(metrics["error"])
            else:
                diag = market_model.get_diagnostics()
                health = diag.get("health", {})
                if health.get("color") == "red":
                    st.error(f"{health['status']}: {metrics['accuracy']}%")
                elif health.get("color") == "orange":
                    st.warning(
                        f"{health['status']}: {metrics['accuracy']}%")
                else:
                    st.success(
                        f"{health['status']}: {metrics['accuracy']}%")
                st.info(health.get("advice", ""))
        except Exception as e:
            st.error(f"Ошибка: {e}")
        finally:
            progress_bar.empty()
            status_txt.empty()

    if market_model.is_trained:
        st.markdown("---")
        st.markdown("### Прогнозы по акциям")

        # Кэш прогнозов всех акций
        if "ml_predict_all" not in st.session_state:
            with st.spinner("Прогнозирование..."):
                st.session_state["ml_predict_all"] = \
                    market_model.predict_all()

        if st.button("Обновить прогнозы", key="refresh_ml_all"):
            st.session_state["ml_predict_all"] = \
                market_model.predict_all()

        pred_df = st.session_state["ml_predict_all"]

        if not pred_df.empty:
            pc1, pc2 = st.columns(2)
            pred_filter = pc1.selectbox("Показать",
                ["Все", "Покупать (>60%)", "Продавать (<40%)"],
                key="pred_f")
            pred_sector = pc2.selectbox("Сектор",
                ["Все"] + sorted(pred_df["Сектор"].unique().tolist()),
                key="pred_s")

            display_df = pred_df.copy()
            if pred_filter == "Покупать (>60%)":
                display_df = display_df[
                    display_df["Вероятн. роста %"] > 60]
            elif pred_filter == "Продавать (<40%)":
                display_df = display_df[
                    display_df["Вероятн. роста %"] < 40]
            if pred_sector != "Все":
                display_df = display_df[
                    display_df["Сектор"] == pred_sector]
            st.dataframe(display_df, use_container_width=True,
                         height=500)

            st.markdown("### Детальный ML-прогноз")
            dt = st.selectbox("Тикер", TICKERS, key="ml_detail")
            if st.button("Показать", key="show_pred"):
                pred = market_model.predict_ticker(dt)
                if pred.get("error"):
                    st.warning(f"ML: {pred['error']}")
                p1, p2, p3 = st.columns(3)
                p1.metric("Прогноз", pred.get("prediction", "—"))
                p2.metric("Вер. роста", f"{pred.get('prob_up', 50)}%")
                p3.metric("Уверенность", pred.get("confidence", "—"))
                if pred.get("explanations"):
                    st.markdown("**Почему:**")
                    for exp in pred["explanations"]:
                        st.markdown(f"- {exp}")

            st.markdown("### Секторный анализ")
            recs = market_model.get_market_recommendations()
            if "error" not in recs:
                st.markdown(
                    f"**Средняя вер. роста:** {recs['market_avg']}%")
                rc1, rc2, rc3 = st.columns(3)
                with rc1:
                    st.markdown("#### Покупать")
                    for it in recs.get("buy", [])[:10]:
                        st.markdown(
                            f"**{it['Тикер']}** — "
                            f"{it['Вероятн. роста %']}%")
                with rc2:
                    st.markdown("#### Держать")
                    for it in recs.get("hold", [])[:10]:
                        st.markdown(
                            f"**{it['Тикер']}** — "
                            f"{it['Вероятн. роста %']}%")
                with rc3:
                    st.markdown("#### Продавать")
                    for it in recs.get("sell", [])[:10]:
                        st.markdown(
                            f"**{it['Тикер']}** — "
                            f"{it['Вероятн. роста %']}%")
    else:
        st.info("Настройте параметры и нажмите 'Обучить модель'.")


# ============================================================
# TAB 4: ДИАГНОСТИКА ML
# ============================================================
with tab4:
    st.subheader("Диагностика ML-модели")

    if not market_model.is_trained:
        st.info("Модель не обучена.")
    else:
        diag = market_model.get_diagnostics()
        if not diag:
            st.warning("Нет данных.")
        else:
            health = diag.get("health", {})
            color = health.get("color", "gray")
            if color == "red":
                st.error(f"Состояние: {health.get('status')}")
            elif color == "orange":
                st.warning(f"Состояние: {health.get('status')}")
            else:
                st.success(f"Состояние: {health.get('status')}")
            st.info(health.get("advice", ""))

            st.markdown("### Метрики")
            dm1, dm2, dm3, dm4 = st.columns(4)
            dm1.metric("Train", f"{diag.get('train_accuracy', 0):.1f}%")
            dm2.metric("Val", f"{diag.get('val_accuracy', 0):.1f}%")
            dm3.metric("Overfit gap",
                       f"{diag.get('overfit_gap', 0):.1f}%")
            dm4.metric("Строк", f"{diag.get('total_samples', 0):,}")

            fold_details = diag.get("fold_details", [])
            if fold_details:
                st.markdown("### Фолды")
                fold_df = pd.DataFrame(fold_details)
                fig_f = go.Figure()
                fig_f.add_trace(go.Scatter(
                    x=fold_df["Фолд"], y=fold_df["Train Acc %"],
                    name="Train", mode="lines+markers",
                    line=dict(color="#4fc3f7")))
                fig_f.add_trace(go.Scatter(
                    x=fold_df["Фолд"], y=fold_df["Val Acc %"],
                    name="Val", mode="lines+markers",
                    line=dict(color="#ff7043")))
                fig_f.add_hline(y=50, line_dash="dash",
                                line_color="gray")
                fig_f.update_layout(template="plotly_dark", height=400,
                                    yaxis=dict(range=[40, 100]))
                st.plotly_chart(fig_f, use_container_width=True)
                st.dataframe(fold_df, use_container_width=True,
                             hide_index=True)

            cm = diag.get("confusion_matrix")
            if cm is not None:
                st.markdown("### Матрица ошибок")
                fig_cm = px.imshow(
                    np.array(cm), text_auto=True,
                    x=["Падение", "Рост"],
                    y=["Факт: Пад.", "Факт: Рост"],
                    color_continuous_scale="Blues")
                fig_cm.update_layout(template="plotly_dark", height=400)
                st.plotly_chart(fig_cm, use_container_width=True)

            if market_model.feature_importance is not None:
                st.markdown("### Важность признаков")
                imp = market_model.feature_importance
                labels = [FEATURE_NAMES_RU.get(f, f) for f in imp.index]
                fig_i = go.Figure(go.Bar(
                    x=imp.values * 100, y=labels,
                    orientation="h", marker_color="#4fc3f7"))
                fig_i.update_layout(template="plotly_dark", height=600,
                    yaxis=dict(autorange="reversed"))
                st.plotly_chart(fig_i, use_container_width=True)

            if market_model.market_insights:
                st.markdown("### Инсайты")
                for ins in market_model.market_insights:
                    st.markdown(f"- {ins}")