import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from data.moex import get_shares_realtime, get_index_current, get_index_history, get_etf_list
from analysis.groq_advisor import analyze_market
from config import MOEX_TICKERS, MOEX_SECTORS
st.set_page_config(page_title="Рынок", layout="wide")
st.title("Российский фондовый рынок")

# --- Индексы ---
st.header("Индексы")
indices = get_index_current()

if indices:
    cols = st.columns(len(indices))
    for i, (idx, data) in enumerate(indices.items()):
        value = data.get("value")
        change = data.get("change_%")
        if value:
            cols[i].metric(
                f"{idx} ({data.get('name', '')})",
                f"{value:,.0f}",
                f"{change:+.2f}%" if change else None,
            )

# График IMOEX
st.subheader("Индекс IMOEX")
period = st.selectbox("Период", [90, 180, 365, 730], index=2,
                       format_func=lambda x: f"{x} дней")
with st.spinner("Загрузка..."):
    imoex = get_index_history("IMOEX", days=period)

if not imoex.empty and "CLOSE" in imoex.columns:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=imoex["TRADEDATE"], y=imoex["CLOSE"],
                              fill="tozeroy", name="IMOEX",
                              line=dict(color="#1f77b4", width=2)))
    fig.update_layout(title="Индекс Мосбиржи", height=450,
                     yaxis_title="Пункты")
    st.plotly_chart(fig, use_container_width=True)

# --- Котировки ---
st.header("Котировки акций")
with st.spinner("Загрузка котировок..."):
    shares = get_shares_realtime()

if not shares.empty:
    # Фильтр голубых фишек
    blue_chips = shares[shares["SECID"].isin(MOEX_TICKERS)].copy()

    if not blue_chips.empty:
        display = blue_chips.rename(columns={
            "SECID": "Тикер", "SHORTNAME": "Название", "LAST": "Цена",
            "LASTTOPREVPRICE": "Изм. %", "VALTODAY": "Объём (руб)",
            "HIGH": "Макс.", "LOW": "Мин.",
        })
        st.dataframe(
            display[["Тикер", "Название", "Цена", "Изм. %", "Макс.", "Мин.", "Объём (руб)"]],
            use_container_width=True, hide_index=True,
        )

    # Хитмап секторов
    st.subheader("Хитмап по секторам")
    treemap_data = []
    for _, row in blue_chips.iterrows():
        ticker = row["SECID"]
        change = row.get("LASTTOPREVPRICE", 0) or 0
        treemap_data.append({
            "Сектор": MOEX_SECTORS.get(ticker, "Другое"),
            "Тикер": ticker,
            "Изм. %": round(change, 2),
            "abs": max(abs(change), 0.1),
        })

    df_tm = pd.DataFrame(treemap_data)
    if not df_tm.empty:
        fig = px.treemap(df_tm, path=["Сектор", "Тикер"], values="abs",
                        color="Изм. %", color_continuous_scale="RdYlGn",
                        color_continuous_midpoint=0,
                        title="Изменение цен по секторам")
        fig.update_layout(height=600)
        st.plotly_chart(fig, use_container_width=True)

# --- ETF ---
st.header("ETF / БПИФ")
with st.spinner("Загрузка ETF..."):
    etf = get_etf_list()

if not etf.empty:
    etf_display = etf.rename(columns={
        "SECID": "Тикер", "SHORTNAME": "Название", "LAST": "Цена",
        "LASTTOPREVPRICE": "Изм. %", "VALTODAY": "Объём",
    })
    st.dataframe(etf_display[["Тикер", "Название", "Цена", "Изм. %", "Объём"]].head(20),
                 use_container_width=True, hide_index=True)

# --- AI ---
st.header("AI-анализ рынка")
if st.button("Запустить AI-анализ"):
    data_lines = []
    if indices:
        for idx, d in indices.items():
            change = d.get('change_%') or 0
            data_lines.append(f"{idx}: {d.get('value', '?')} ({change:+.2f}%)")
    # Берём данные из shares, не из blue_chips
    if not shares.empty:
        top = shares[shares["SECID"].isin(MOEX_TICKERS)].head(15)
        for _, row in top.iterrows():
            change = row.get("LASTTOPREVPRICE") or 0
            data_lines.append(f"{row['SECID']}: {row.get('LAST', '?')} руб ({change:+.1f}%)")

    if not data_lines:
        st.warning("Нет данных для анализа.")
    else:
        with st.spinner("AI анализирует..."):
            result = analyze_market("\n".join(data_lines))
        st.markdown(result)