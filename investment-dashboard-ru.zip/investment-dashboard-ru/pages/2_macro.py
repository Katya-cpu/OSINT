import streamlit as st
import plotly.graph_objects as go
from data.cbr import get_daily_rates, get_currency_history, get_key_rate_history, get_all_currencies
st.set_page_config(page_title="Макро", layout="wide")
st.title("Макроэкономика России")

# --- Курсы валют ---
st.header("Курсы ЦБ РФ")
rates = get_daily_rates()

if rates and rates.get("currencies"):
    cur = rates["currencies"]
    cols = st.columns(4)

    for i, code in enumerate(["USD", "EUR", "CNY", "GBP"]):
        if code in cur:
            c = cur[code]
            cols[i].metric(
                f"{code}/RUB",
                f"{c['value']:.2f}",
                f"{c['change']:+.4f}",
            )

    # Все валюты
    with st.expander("Все валюты"):
        all_cur = get_all_currencies()
        if not all_cur.empty:
            st.dataframe(all_cur, use_container_width=True, hide_index=True)

# --- История курсов ---
st.header("Динамика курса валюты")
col1, col2 = st.columns(2)
currency = col1.selectbox("Валюта", ["USD", "EUR", "CNY", "GBP"])
days = col2.selectbox("Период", [90, 180, 365, 730], index=2,
                       format_func=lambda x: f"{x} дней")

with st.spinner("Загрузка истории..."):
    hist = get_currency_history(currency, days=days)

if not hist.empty:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=hist["date"], y=hist["value"],
                              fill="tozeroy", name=f"{currency}/RUB",
                              line=dict(width=2)))
    fig.update_layout(title=f"Курс {currency}/RUB", height=450,
                     yaxis_title="Рубли")
    st.plotly_chart(fig, use_container_width=True)

# --- Ключевая ставка ---
st.header("Ключевая ставка ЦБ РФ")
with st.spinner("Загрузка..."):
    key_rate = get_key_rate_history()

if not key_rate.empty:
    current_rate = key_rate["rate"].iloc[-1]
    prev_rate = key_rate["rate"].iloc[-2] if len(key_rate) > 1 else current_rate
    st.metric("Текущая ставка", f"{current_rate}%", f"{current_rate - prev_rate:+.2f}%")

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=key_rate["date"], y=key_rate["rate"],
                              mode="lines+markers", name="Ключевая ставка",
                              line=dict(color="red", width=2, shape="hv")))
    fig.update_layout(title="Ключевая ставка ЦБ РФ", height=450,
                     yaxis_title="%")
    st.plotly_chart(fig, use_container_width=True)

    # Выводы
    if current_rate >= 15:
        st.warning(f"Ставка {current_rate}% — высокая. Облигации и депозиты привлекательны. Рынок акций под давлением.")
    elif current_rate >= 10:
        st.info(f"Ставка {current_rate}% — умеренно высокая. Баланс между акциями и облигациями.")
    else:
        st.success(f"Ставка {current_rate}% — низкая. Акции и рисковые активы привлекательны.")

# --- AI ---
st.header("AI-анализ макроэкономики")
if st.button("Запустить AI-анализ"):
    from analysis.groq_advisor import analyze_macro
    data_lines = []
    if rates and rates.get("currencies"):
        for code in ["USD", "EUR", "CNY"]:
            if code in rates["currencies"]:
                data_lines.append(f"{code}/RUB: {rates['currencies'][code]['value']:.2f}")
    if not key_rate.empty:
        data_lines.append(f"Ключевая ставка ЦБ: {key_rate['rate'].iloc[-1]}%")

    with st.spinner("AI анализирует..."):
        result = analyze_macro("\n".join(data_lines))
    st.markdown(result)