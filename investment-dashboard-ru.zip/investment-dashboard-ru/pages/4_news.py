import streamlit as st
from data.news_ru import get_all_news, get_market_news, search_news
from analysis.groq_advisor import analyze_news_sentiment
st.set_page_config(page_title="Новости", layout="wide")
st.title("Российские деловые новости")

tab1, tab2, tab3 = st.tabs(["Рыночные новости", "Все новости", "Поиск"])

with tab1:
    st.header("Новости фондового рынка")
    if st.button("Загрузить рыночные новости"):
        with st.spinner("Загрузка из RSS..."):
            news = get_market_news(limit=20)

        if not news:
            st.info("Новостей не найдено.")
        else:
            for a in news:
                with st.expander(f"[{a.get('source', '')}] {a['title']}"):
                    st.markdown(f"<strong>Дата:</strong> {a.get('published', '?')}")
                    if a.get("description"):
                        st.write(a["description"])
                    link = a.get("link") or a.get("url")
                    if link:
                        st.markdown(f"<a href='{link}' class='md-link'>Читать полностью</a>")

            # AI-сентимент
            st.subheader("AI-анализ сентимента")
            if st.button("Анализировать сентимент"):
                news_text = "\n".join(
                    f"{i+1}. {a['title']}" for i, a in enumerate(news[:15])
                )
                with st.spinner("AI анализирует..."):
                    result = analyze_news_sentiment(news_text)
                st.markdown(result)

with tab2:
    st.header("Все новости")
    if st.button("Загрузить все новости"):
        with st.spinner("Загрузка..."):
            news = get_all_news(limit_per_source=15)
        for a in news:
            with st.expander(f"[{a.get('source', '')}] {a['title']}"):
                st.markdown(f"<strong>Дата:</strong> {a.get('published', '?')}")
                if a.get("description"):
                    st.write(a["description"])
                link = a.get("link") or a.get("url")
                if link:
                    st.markdown(f"<a href='{link}' class='md-link'>Читать полностью</a>")

with tab3:
    st.header("Поиск по теме")
    query = st.text_input("Ключевое слово",
                          placeholder="Сбер, нефть, дивиденды...")

    if st.button("Искать", key="search"):
        if not query:
            st.warning("Введи запрос")
        else:
            with st.spinner("Поиск..."):
                results = search_news(query, limit=20)
            if not results:
                st.info("Ничего не найдено. Попробуй другой запрос.")
            else:
                st.write(f"Найдено: {len(results)}")
                for a in results:
                    with st.expander(
                        f"[{a.get('source', '')}] {a['title']}"
                    ):
                        st.markdown(
                            f"<strong>Дата:</strong> {a.get('published', '?')}")
                        if a.get("description"):
                            st.write(a["description"])
                        link = a.get("link") or a.get("url")
                        if link:
                            st.markdown(f"<a href='{link}' class='md-link'>Читать полностью</a>")