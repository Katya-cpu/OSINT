import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
from analysis.portfolio import calculate_portfolio, format_portfolio_for_llm
from analysis.groq_advisor import analyze_portfolio
from config import MOEX_TICKERS
st.set_page_config(page_title="Портфель", layout="wide")
st.title("Анализ портфеля")

# --- Ввод ---
if "portfolio" not in st.session_state:
    st.session_state.portfolio = {
        "SBER": 100000, "GAZP": 80000, "LKOH": 70000,
        "YNDX": 50000, "GMKN": 40000,
    }

st.header("Состав портфеля")

col1, col2, col3 = st.columns([2, 2, 1])
new_ticker = col1.selectbox("Тикер", MOEX_TICKERS)
new_amount = col2.number_input("Сумма (руб)", min_value=1000, value=50000, step=10000)
if col3.button("Добавить"):
    st.session_state.portfolio[new_ticker] = new_amount
    st.rerun()

# Текущий портфель как таблица
portfolio_df = pd.DataFrame([
    {"Тикер": t, "Сумма (руб)": f"{v:,.0f}"} for t, v in st.session_state.portfolio.items()
])
st.dataframe(portfolio_df, use_container_width=True, hide_index=True)

total = sum(st.session_state.portfolio.values())
st.metric("Итого", f"{total:,.0f} руб.")

# Удаление
to_remove = st.multiselect("Удалить из портфеля", list(st.session_state.portfolio.keys()))
if to_remove and st.button("Удалить"):
    for t in to_remove:
        del st.session_state.portfolio[t]
    st.rerun()

# --- Анализ ---
if st.button("Анализировать портфель"):
    with st.spinner("Загрузка данных и расчёт (может занять 1-2 мин)..."):
        metrics = calculate_portfolio(st.session_state.portfolio)

    if "error" in metrics:
        st.error(metrics["error"])
        st.stop()

    st.header("Метрики")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Годовая доходность", f"{metrics['annual_return_%']:+.1f}%")
    c2.metric("Волатильность", f"{metrics['annual_volatility_%']:.1f}%")
    c3.metric("Sharpe Ratio", f"{metrics['sharpe_ratio']:.2f}")
    c4.metric("Max Drawdown", f"{metrics['max_drawdown_%']:.1f}%")

    # Pie
    fig = px.pie(values=list(metrics["weights"].values()),
                 names=list(metrics["weights"].keys()),
                 title="Распределение портфеля")
    st.plotly_chart(fig, use_container_width=True)

    # Кумулятивная доходность
    cum = metrics["cumulative_returns"]
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=cum.index, y=cum.values, fill="tozeroy", name="Портфель"))
    fig.update_layout(title="Кумулятивная доходность", height=400,
                     yaxis_title="Рост 1 рубля")
    st.plotly_chart(fig, use_container_width=True)

    # Корреляция
    st.subheader("Корреляция активов")
    corr = metrics["correlation"]
    fig = px.imshow(corr, text_auto=".2f", color_continuous_scale="RdBu_r",
                    zmin=-1, zmax=1)
    st.plotly_chart(fig, use_container_width=True)

    # Метрики по активам
    st.subheader("Метрики по активам")
    am_df = pd.DataFrame(metrics["asset_metrics"]).T
    am_df.index.name = "Тикер"
    st.dataframe(am_df, use_container_width=True)

    # AI
    st.header("AI-анализ портфеля")
    if st.button("Запустить AI-анализ"):
        portfolio_str = format_portfolio_for_llm(metrics)
        with st.spinner("AI анализирует..."):
            result = analyze_portfolio(portfolio_str)
        st.markdown(result)